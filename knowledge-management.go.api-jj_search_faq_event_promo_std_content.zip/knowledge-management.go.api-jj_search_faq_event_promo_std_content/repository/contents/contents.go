package contents

import (
	dr "boilerplate-go-fiber/domain/contents"
	"boilerplate-go-fiber/infra"

	"github.com/sirupsen/logrus"
)

type ContentsDataRepo struct {
	DBList *infra.DatabaseList
	Log    *logrus.Logger
}

func newContentsDataRepo(dbList *infra.DatabaseList, logger *logrus.Logger) ContentsDataRepo {
	return ContentsDataRepo{
		DBList: dbList,
		Log:    logger,
	}
}

const (
	uqGetContents = `
	select rowno,id,title,description,createdate,publishdate,totalrow from public.sp_search_article_get_list_paging(1,10,'');
	`

	queryGetContentsPaging = `
	select rowno,id,title,description,createdate,publishdate,totalrow from public.sp_search_article_get_list_paging(?,?,?);
	`
)

type ContentsDataRepoItf interface {
	GetContents() ([]dr.ContentsData, error)
	GetListByPage(data dr.ContentListPaggingRequest) ([]dr.ContentsData, error)

	// CreateProduct(ctx context.Context, arg dr.CreateRoleParam) (error, *dr.CreateRoleScan)
	// GetProducByProductId(ctx context.Context, roleId int64) (error, *dr.GetRoleScan)
	// GetProductByProductName(ctx context.Context, roleName string) (error, *dr.GetRoleScan)
	//GetAllProduct() ([]dr.ContentsData, error)
	// ListProductWithLimit(ctx context.Context, page int, pageSize int) (error, *[]dr.ListRoleScan, int)
	// UpdateProduct(ctx context.Context, arg dr.UpdateRoleParam) (error, *dr.UpdateRoleScan)
}

func (ur ContentsDataRepo) GetContents() ([]dr.ContentsData, error) {
	var result []dr.ContentsData

	q := uqGetContents
	query, args, err := ur.DBList.KNOWLEDGEMANAGEMENTDB.Read.In(q)
	ur.Log.Info("test ")
	if err != nil {
		return nil, err
	}

	query = ur.DBList.KNOWLEDGEMANAGEMENTDB.Read.Rebind(query)
	err = ur.DBList.KNOWLEDGEMANAGEMENTDB.Read.Select(&result, query, args...)
	ur.Log.Info(err)
	if err != nil {
		return result, err
	}

	return result, nil
}

func (ur ContentsDataRepo) GetListByPage(data dr.ContentListPaggingRequest) ([]dr.ContentsData, error) {
	var result []dr.ContentsData

	// var isActive int = -1

	// if data.IsActive != nil {
	// 	if *data.IsActive == false {
	// 		isActive = 0
	// 	} else if *data.IsActive == true {
	// 		isActive = 1
	// 	}
	// }

	param := make([]interface{}, 0)

	param = append(param, data.Pagging.PageNumber)
	param = append(param, data.Pagging.PageSize)
	param = append(param, data.Pagging.SearchKey)

	query, args, err := ur.DBList.KNOWLEDGEMANAGEMENTDB.Read.In(queryGetContentsPaging, param...)
	if err != nil {
		return nil, err
	}

	query = ur.DBList.KNOWLEDGEMANAGEMENTDB.Read.Rebind(query)
	err = ur.DBList.KNOWLEDGEMANAGEMENTDB.Read.Select(&result, query, args...)
	if err != nil {
		return result, err
	}

	return result, nil
}
