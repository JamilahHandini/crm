package config

import (
	"boilerplate-go-fiber/domain/general"

	"github.com/spf13/viper"
)

func GetCoreConfig() (*general.SectionService, error) {
	viper.SetConfigName("core")
	viper.AddConfigPath(".")
	viper.AutomaticEnv()
	viper.SetConfigType("yml")

	err := viper.ReadInConfig()
	if err != nil {
		return nil, err
	}

	data := &general.SectionService{
		App: general.AppAccount{
			Name:         viper.GetString("APP.NAME"),
			Environtment: viper.GetString("APP.ENV"),
			URL:          viper.GetString("APP.URL"),
			Port:         viper.GetString("APP.PORT"),
			SecretKey:    viper.GetString("APP.KEY"),
			Endpoint:     viper.GetString("APP.ENDPOINT"),
			BodyLimit:    viper.GetInt("APP.BODYLIMIT"),
		},
		Database: general.DatabaseAccount{
			Username:     viper.GetString("DATABASE.USERNAME"),
			Password:     viper.GetString("DATABASE.PASSWORD"),
			URL:          viper.GetString("DATABASE.URL"),
			Port:         viper.GetString("DATABASE.PORT"),
			DBName:       viper.GetString("DATABASE.NAME"),
			SSLMode:      viper.GetString("DATABASE.SSL_MODE"),
			TimeZone:     viper.GetString("DATABASE.TIMEZONE"),
			MaxIdleConns: viper.GetInt("DATABASE.MAXIDLECONNS"),
			MaxOpenConns: viper.GetInt("DATABASE.MAXOPENCONNS"),
			MaxLifeTime:  viper.GetInt("DATABASE.MAXLIFETIME"),
			MaxIdleTime:  viper.GetInt("DATABASE.MAXIDLETIME"),
		},

		Route: general.RouteAccount{
			Methods: viper.GetString("ROUTES.METHODS"),
			Headers: viper.GetString("ROUTES.HEADERS"),
			Origins: general.RouteOrigin{
				Default: viper.GetString("ROUTES.ORIGINS.DEFAULT"),
			},
		},
		ConnectionDB: general.ConnectionDBAccount{
			LOCALSQLSERVERDB: general.ConnectionDBDetailAccount{
				DriverName:   viper.GetString("CONNECTIONDB.LOCALSQLSERVERDB.DRIVERNAME"),
				DriverSource: viper.GetString("CONNECTIONDB.LOCALSQLSERVERDB.DRIVERSOURCE"),
				MaxIdleConns: viper.GetInt("CONNECTIONDB.LOCALSQLSERVERDB.MAXIDLECONNS"),
				MaxOpenConns: viper.GetInt("CONNECTIONDB.LOCALSQLSERVERDB.MAXOPENCONNS"),
				MaxLifeTime:  viper.GetInt("CONNECTIONDB.LOCALSQLSERVERDB.MAXLIFETIME"),
			},
			LOCALPOSTGREESQLDB: general.ConnectionDBDetailAccount{
				DriverName:   viper.GetString("CONNECTIONDB.LOCALPOSTGREESQLDB.DRIVERNAME"),
				DriverSource: viper.GetString("CONNECTIONDB.LOCALPOSTGREESQLDB.DRIVERSOURCE"),
				MaxIdleConns: viper.GetInt("CONNECTIONDB.LOCALPOSTGREESQLDB.MAXIDLECONNS"),
				MaxOpenConns: viper.GetInt("CONNECTIONDB.LOCALPOSTGREESQLDB.MAXOPENCONNS"),
				MaxLifeTime:  viper.GetInt("CONNECTIONDB.LOCALPOSTGREESQLDB.MAXLIFETIME"),
			},
			KNOWLEDGEMANAGEMENTDB: general.ConnectionDBDetailAccount{
				DriverName:   viper.GetString("CONNECTIONDB.KNOWLEDGEMANAGEMENTDB.DRIVERNAME"),
				DriverSource: viper.GetString("CONNECTIONDB.KNOWLEDGEMANAGEMENTDB.DRIVERSOURCE"),
				MaxIdleConns: viper.GetInt("CONNECTIONDB.KNOWLEDGEMANAGEMENTDB.MAXIDLECONNS"),
				MaxOpenConns: viper.GetInt("CONNECTIONDB.KNOWLEDGEMANAGEMENTDB.MAXOPENCONNS"),
				MaxLifeTime:  viper.GetInt("CONNECTIONDB.KNOWLEDGEMANAGEMENTDB.MAXLIFETIME"),
			},
		},
		CloudStorage: general.CloudStorageAccount{
			GoogleStorage: general.GoogleStorage{
				GoogleCredentialsFile:    viper.GetString("CLOUD_STORAGE.GOOGLE_STORAGE.GOOGLE_CREDENTIALS_FILE"),
				GoogleCLoudStorageBucket: viper.GetString("CLOUD_STORAGE.GOOGLE_STORAGE.GOOGLE_CLOUD_STORAGE_BUCKET"),
				GoogleCloudStorageUrl:    viper.GetString("CLOUD_STORAGE.GOOGLE_STORAGE.GOOGLE_CLOUD_STORAGE_URL"),
				AppName:                  viper.GetString("CLOUD_STORAGE.GOOGLE_STORAGE.APPNAME"),
			},
		},
		Authorization: general.AuthAccount{
			JWT: general.JWTCredential{
				IsActive:              viper.GetBool("AUTHORIZATION.JWT.IS_ACTIVE"),
				AccessTokenSecretKey:  viper.GetString("AUTHORIZATION.JWT.ACCESS_TOKEN_SECRET_KEY"),
				AccessTokenDuration:   viper.GetInt("AUTHORIZATION.JWT.ACCESS_TOKEN_DURATION"),
				RefreshTokenSecretKey: viper.GetString("AUTHORIZATION.JWT.REFRESH_TOKEN_SECRET_KEY"),
				RefreshTokenDuration:  viper.GetInt("AUTHORIZATION.JWT.REFRESH_TOKEN_DURATION"),
			},
			Public: general.PublicCredential{
				SecretKey: viper.GetString("AUTHORIZATION.PUBLIC.SECRECT_KEY"),
			},
		},
	}

	return data, nil
}
