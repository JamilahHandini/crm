package utils

import (
	"crypto/sha256"
	"encoding/base64"
	"fmt"
	"log"
	mathRand "math/rand"
	"time"

	uuid "github.com/nu7hatch/gouuid"
	"github.com/spf13/viper"
	"golang.org/x/crypto/bcrypt"
	"golang.org/x/exp/utf8string"
)

func GetUUID() (string, error) {
	uuid, err := uuid.NewV4()
	if err != nil {
		return "", err
	}

	return uuid.String(), nil
}

func GeneratePassword(password string) (string, error) {
	hashedPassword, err := bcrypt.GenerateFromPassword([]byte(password), 14)
	if err != nil {
		return "", err
	}

	return string(hashedPassword), nil
}

func ComparePassword(savedPass, incomingPass string) (bool, error) {
	err := bcrypt.CompareHashAndPassword([]byte(savedPass), []byte(incomingPass))
	if err != nil {
		return false, nil
	}

	return true, nil
}

var seededRand *mathRand.Rand = mathRand.New(mathRand.NewSource(time.Now().UnixNano()))

func GenerateStringWithCharset(length int, charset string) string {
	b := make([]byte, length)
	for i := range b {
		b[i] = charset[seededRand.Intn(len(charset))]
	}
	return string(b)
}

func GenerateBasicToken(phone string, timeStamp string) string {

	apiKey := viper.GetString("EXTERNAL.API.DMQIAPI.CLIENT_API_KEY")
	apiSecret := viper.GetString("EXTERNAL.API.DMQIAPI.CLIENT_API_SECRET")

	message := fmt.Sprintf("%s:%s:%s:%v", apiKey, apiSecret, phone, timeStamp)

	hash := sha256.Sum256([]byte(message))

	wordArray := utf8string.NewString(fmt.Sprintf("%s:%x", apiKey, hash))

	secret_buffer := base64.StdEncoding.EncodeToString([]byte(wordArray.String()))
	return secret_buffer
}

func GenerateTimeNowJakarta() time.Time {
	loc, err := time.LoadLocation("Asia/Jakarta")
	if err != nil {
		log.Println(err)
	}
	now := time.Now().In(loc)
	return now
}
