package role

import (
	"boilerplate-go-fiber/domain/general"
	"boilerplate-go-fiber/repository"
	"database/sql"

	"github.com/sirupsen/logrus"
)

type RoleUsecase struct {
	Role RoleDataUsecaseItf
}

func NewUsecase(repo repository.Repo, conf *general.SectionService, db *sql.DB, logger *logrus.Logger) RoleUsecase {
	return RoleUsecase{
		Role: newRoleDataUsecase(repo, conf, db, logger),
	}
}
