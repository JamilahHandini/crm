package core

import (
	"boilerplate-go-fiber/domain/general"
	"boilerplate-go-fiber/handler/core/contents"
	"boilerplate-go-fiber/handler/core/product"
	"boilerplate-go-fiber/handler/core/role"
	"boilerplate-go-fiber/handler/core/users"
	"boilerplate-go-fiber/usecase"

	"github.com/sirupsen/logrus"
)

type CoreHandler struct {
	Role     role.RoleHandler
	Product  product.ProductHandler
	Contents contents.ContentsHandler
	Users    users.UsersHandler
}

// func NewHandler(uc usecase.Usecase, conf *general.SectionService, log *logrus.Logger) CoreHandler {
// 	return CoreHandler{
// 		//Role:    role.NewCoreHandler(uc, conf, log),
// 		Product: product.NewCoreHandler(uc, conf, logger),
// 	}
// }

func NewCoreHandler(uc usecase.Usecase, conf *general.SectionService, logger *logrus.Logger) CoreHandler {
	return CoreHandler{
		Contents: contents.NewCoreHandler(uc, conf, logger),
		Product:  product.NewCoreHandler(uc, conf, logger),
		Users:    users.NewCoreHandler(uc, conf, logger),
	}
}
