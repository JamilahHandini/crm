package role

import "time"

type RoleEntity struct {
	RoleID    int64      `json:"role_id"`
	RoleName  string     `json:"role_name"`
	CreatedBy string     `json:"created_by"`
	CreatedAt time.Time  `json:"created_at"`
	UpdatedBy *string    `json:"updated_by"`
	UpdatedAt *time.Time `json:"updated_at"`
	IsActive  bool       `json:"is_active"`
}

//* Create
type CreateRoleRequest struct {
	RoleName string `json:"role_name" validate:"required"`
	IsActive bool   `json:"is_active" validate:"required"`
}
type CreateRoleParam struct {
	RoleName  string    `json:"role_name"`
	CreatedBy string    `json:"created_by"`
	CreatedAt time.Time `json:"created_at"`
	IsActive  bool      `json:"is_active"`
}

type CreateRoleScan struct {
	RoleID    int64     `json:"role_id"`
	RoleName  string    `json:"role_name"`
	CreatedBy string    `json:"created_by"`
	CreatedAt time.Time `json:"created_at"`
	IsActive  bool      `json:"is_active"`
}

//* List
type ListRoleScan struct {
	RoleID    int64      `json:"role_id"`
	RoleName  string     `json:"role_name"`
	CreatedBy string     `json:"created_by"`
	CreatedAt time.Time  `json:"created_at"`
	UpdatedBy *string    `json:"updated_by"`
	UpdatedAt *time.Time `json:"updated_at"`
	IsActive  bool       `json:"is_active"`
}

//* Get
type GetRoleScan struct {
	RoleID    int64      `json:"role_id"`
	RoleName  string     `json:"role_name"`
	CreatedBy string     `json:"created_by"`
	CreatedAt time.Time  `json:"created_at"`
	UpdatedBy *string    `json:"updated_by"`
	UpdatedAt *time.Time `json:"updated_at"`
	IsActive  bool       `json:"is_active"`
}

//* Update
type UpdateStatusRoleRequest struct {
	RoleID   int64 `json:"role_id"`
	IsActive bool  `json:"is_active"`
}

type UpdateRoleParam struct {
	RoleID    int64      `json:"role_id"`
	RoleName  string     `json:"role_name"`
	UpdatedBy *string    `json:"updated_by"`
	UpdatedAt *time.Time `json:"updated_at"`
	IsActive  bool       `json:"is_active"`
}

type UpdateRoleScan struct {
	RoleID    int64      `json:"role_id"`
	RoleName  string     `json:"role_name"`
	UpdatedBy *string    `json:"updated_by"`
	UpdatedAt *time.Time `json:"updated_at"`
	IsActive  bool       `json:"is_active"`
}

//* Update Status Role
type UpdateRoleRequest struct {
	RoleID   int64  `json:"role_id"`
	RoleName string `json:"role_name"`
	IsActive bool   `json:"is_active"`
}
type UpdateStatusRoleParam struct {
	RoleID    int64      `json:"role_id"`
	UpdatedBy *string    `json:"updated_by"`
	UpdatedAt *time.Time `json:"updated_at"`
	IsActive  bool       `json:"is_active"`
}

type UpdateStatusRoleScan struct {
	RoleID    int64      `json:"role_id"`
	RoleName  string     `json:"role_name"`
	UpdatedBy *string    `json:"updated_by"`
	UpdatedAt *time.Time `json:"updated_at"`
	IsActive  bool       `json:"is_active"`
}
