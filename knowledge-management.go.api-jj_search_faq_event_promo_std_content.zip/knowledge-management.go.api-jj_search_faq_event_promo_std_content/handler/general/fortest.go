package general

import (
	"boilerplate-go-fiber/exception"
	"bytes"
	"encoding/json"
	"io/ioutil"
	"net/http"

	"github.com/gofiber/fiber/v2"
)

//* Test generate UUID
// func (gh GeneralDataHandler) ForTest(c *fiber.Ctx) error {

// 	newUUID, _ := utils.GetUUID()
// 	return c.Status(fiber.StatusOK).JSON(fiber.Map{
// 		"new_uuid": newUUID,
// 	})
// }
//* Test Login OneKalbe
type OneKalbeResponse struct {
	Upn         string `json:"upn"`
	Name        string `json:"name"`
	AccessToken string `json:"accessToken"`
}

func (gh GeneralDataHandler) ForTest(c *fiber.Ctx) error {

	init := exception.InitException(c, gh.conf, gh.log)

	postBody, _ := json.Marshal(map[string]string{
		"username": "Lucia.utami@kalbenutritionals.com",
		"password": "22Sanghiang",
	})
	responseBody := bytes.NewBuffer(postBody)

	resp, err := http.Post("http://10.100.4.116:8237/api/Login", "application/json", responseBody)
	if err != nil {
		return exception.CreateResponse(init, fiber.StatusInternalServerError, err.Error(), err.Error(), nil)
	}
	defer resp.Body.Close()

	bodyBytes, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return exception.CreateResponse(init, fiber.StatusInternalServerError, err.Error(), err.Error(), nil)
	}

	var data OneKalbeResponse
	json.Unmarshal(bodyBytes, &data)

	return exception.CreateResponse(init, fiber.StatusOK, "Success", "Sukses", data)
}
