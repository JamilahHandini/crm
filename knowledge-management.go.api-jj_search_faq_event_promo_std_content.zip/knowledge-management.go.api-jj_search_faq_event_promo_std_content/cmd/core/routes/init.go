package routes

import (
	"boilerplate-go-fiber/domain/general"
	"boilerplate-go-fiber/handler"

	"github.com/gofiber/fiber/v2"
	"github.com/sirupsen/logrus"
)

func SetupRoutes(app *fiber.App, handler handler.Handler, conf *general.SectionService, log *logrus.Logger) {

	//* Root

	app.Get("/", handler.General.General.GetRoot)

	//* Api v1
	api := app.Group(conf.App.Endpoint)
	getProduct(api, handler, conf, log)
	getContents(api, handler, conf, log)
	getUser(api, handler, conf, log)
	//* Core endpoint
	RouteRole(api.Group("/role"), handler)

	//* Fortest
	api.Get("/test", handler.General.General.ForTest)

	//* Prepare an endpoint for 'Not found'
	app.All("*", handler.General.General.Notfound)
}
