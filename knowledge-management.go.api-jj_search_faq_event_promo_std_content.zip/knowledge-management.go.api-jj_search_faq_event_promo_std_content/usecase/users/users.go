package users

import (
	"boilerplate-go-fiber/domain/general"
	dt "boilerplate-go-fiber/domain/users"
	"boilerplate-go-fiber/exception"
	"boilerplate-go-fiber/infra"
	"boilerplate-go-fiber/repository"
	ru "boilerplate-go-fiber/repository/users"
	"fmt"

	"boilerplate-go-fiber/utils"

	"github.com/gofiber/fiber"
	"github.com/sirupsen/logrus"
	"golang.org/x/crypto/bcrypt"
)

type UsersDataUsecaseItf interface {
	GetToken(request dt.LoginUserRequest) (*general.JWTAccess, *general.Error)
}

type UsersDataUsecase struct {
	Repo   ru.UsersDataRepoItf
	DBList *infra.DatabaseList
	Conf   *general.SectionService
	Log    *logrus.Logger
}

func newUsersDataUsecase(r repository.Repo, conf *general.SectionService, logger *logrus.Logger, dbList *infra.DatabaseList) UsersDataUsecase {
	return UsersDataUsecase{
		Repo:   r.Users.Users,
		Conf:   conf,
		Log:    logger,
		DBList: dbList,
	}
}

func (ut UsersDataUsecase) GetToken(request dt.LoginUserRequest) (*general.JWTAccess, *general.Error) {

	if utils.IsNilOrEmpty(request.Email) {
		return nil, exception.NewError(fiber.StatusNotFound, "Email is empty.", "Email kosong.")
	}

	if utils.IsNilOrEmpty(&request.Password) {
		return nil, exception.NewError(fiber.StatusNotFound, "Password is empty.", "Password kosong.")
	}

	resultUser, err := ut.Repo.CheckLoginUser(request)

	// password := []byte(request.Password)
	// existingpass := []byte(resultUser.Password)

	password := []byte("masden2022")

	existingpass := []byte("$2a$10$5fhSOabO4i338aiRK6IKye6mGD5P2M/tQOJmcT3aHjqUl/mWSwMOW")

	//Hashing the password with the default cost of 10
	// hashedPassword, err := bcrypt.GenerateFromPassword(password, bcrypt.DefaultCost)
	// if err != nil {
	// 	panic(err)
	// }
	//userPass := []byte(existingpass)

	isValidPass := bcrypt.CompareHashAndPassword(existingpass, password)

	if resultUser == nil {
		return nil, exception.NewError(fiber.StatusBadRequest, "Users cannot found", "User tidak ditemukan")
	}

	if isValidPass != nil {
		return nil, exception.NewError(fiber.StatusBadRequest, "Wrong password", "Password salah")
	}

	//* Generate JWT
	session, err := utils.GetEncrypt([]byte(ut.Conf.App.SecretKey), fmt.Sprintf("%d", *resultUser.Id))
	if err != nil {
		return nil, exception.NewError(fiber.StatusInternalServerError, "fail to get cmsuser data from infra", "fail to get cmsuser data from infra")
	}

	accessToken, expired, err := utils.GenerateJWTCMSWithClaims(session, int64(*resultUser.Id), *resultUser.Email)
	if err != nil {
		return nil, exception.NewError(fiber.StatusInternalServerError, "fail to get cmsuser data from infra", "fail to get cmsuser data from infra")
	}

	var jwtToken general.JWTAccess
	jwtToken.AccessToken = accessToken
	//jwtToken.RefreshToken = refreshToken
	jwtToken.Expired = expired
	//jwtToken.RTExpired = rtExpired

	return &jwtToken, nil
}
