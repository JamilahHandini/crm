package general

import "time"

type JWTAccess struct {
	AccessToken string     `json:"accessToken"`
	Expired     *time.Time `json:"expired"`
}
