package general

import (
	"github.com/gofiber/fiber/v2"
)

func (gh GeneralDataHandler) GetRoot(c *fiber.Ctx) error {

	return c.Render("start", fiber.Map{
		"Title": gh.conf.App.Name,
	})
}
