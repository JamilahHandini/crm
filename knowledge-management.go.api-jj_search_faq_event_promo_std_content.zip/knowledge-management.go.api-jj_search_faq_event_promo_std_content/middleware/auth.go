package middleware

import (
	"boilerplate-go-fiber/domain/general"
	"boilerplate-go-fiber/exception"
	"boilerplate-go-fiber/utils"
	"fmt"
	"strings"

	"github.com/gofiber/fiber/v2"
	"github.com/sirupsen/logrus"
)

func PICJWTValidator(conf *general.SectionService, log *logrus.Logger) fiber.Handler {
	return func(c *fiber.Ctx) error {

		log.Info("JWT Validator ==>")

		initException := exception.InitException(c, conf, log)

		// authorizationHeader := c.Get("Authorization")
		// if !strings.Contains(authorizationHeader, "Bearer") {
		// 	return exception.CreateResponse_Log(initException, fiber.StatusUnauthorized, "Invalid Token Format", "Invalid Token Format", nil)
		// }

		accessToken := c.Cookies(conf.Cookie.PICAT)

		//accessToken := strings.Replace(authorizationHeader, "Bearer ", "", -1)

		//log.Info(fmt.Sprintf("AT %s", accessToken))

		claims, err := utils.CheckAccessToken(accessToken)
		if err != nil {
			return exception.CreateResponse_Log(initException, fiber.StatusUnauthorized, "Token expired", "Token kadaluwarsa", nil)
		}

		if claims["channel"] == nil {
			return exception.CreateResponse_Log(initException, fiber.StatusUnauthorized, "Token not valid", "Token tidak valid", nil)
		}

		if claims["channel"] != "KnowledgeManagementCMS" {
			return exception.CreateResponse_Log(initException, fiber.StatusUnauthorized, "Token not valid", "Token tidak valid", nil)
		}

		c.Locals("session", claims["session"])
		c.Locals("employeeid", claims["employeeid"])
		c.Locals("cabangid", claims["cabangid"])

		return c.Next()
	}
}

func CMSJWTValidator(conf *general.SectionService, log *logrus.Logger) fiber.Handler {
	return func(c *fiber.Ctx) error {

		log.Info("JWT Validator ==>")

		initException := exception.InitException(c, conf, log)

		accessToken := c.Cookies(conf.Cookie.CMSAT)

		//log.Info(fmt.Sprintf("AT %s", accessToken))

		claims, err := utils.CheckAccessToken(accessToken)
		if err != nil {
			return exception.CreateResponse_Log(initException, fiber.StatusUnauthorized, "Token expired", "Token kadaluwarsa", nil)
		}

		if claims["channel"] == nil {
			return exception.CreateResponse_Log(initException, fiber.StatusUnauthorized, "Token not valid", "Token tidak valid", nil)
		}

		if claims["channel"] != "KnowledgeManagementCMS" {
			return exception.CreateResponse_Log(initException, fiber.StatusUnauthorized, "Token not valid", "Token tidak valid", nil)
		}

		c.Locals("session", claims["session"])
		c.Locals("userid", claims["userid"])
		c.Locals("username", claims["username"])

		return c.Next()
	}
}

func JWTValidator(conf *general.SectionService, log *logrus.Logger) fiber.Handler {
	return func(c *fiber.Ctx) error {

		log.Info("JWT Validator ==>")

		initException := exception.InitException(c, conf, log)

		authorizationHeader := c.Get("Authorization")
		if !strings.Contains(authorizationHeader, "Bearer") {
			return exception.CreateResponse_Log(initException, fiber.StatusUnauthorized, "Invalid Token Format", "Invalid Token Format", nil)
		}
		accessToken := strings.Replace(authorizationHeader, "Bearer ", "", -1)

		log.Info(fmt.Sprintf("AT %s", accessToken))

		claims, err := utils.CheckAccessToken(accessToken)
		if err != nil {
			return exception.CreateResponse_Log(initException, fiber.StatusUnauthorized, "Token expired", "Token kadaluwarsa", nil)
		}

		c.Locals("session", claims["session"])

		return c.Next()
	}
}
