package repository

import (
	"boilerplate-go-fiber/infra"
	"boilerplate-go-fiber/repository/contents"
	"boilerplate-go-fiber/repository/product"
	"boilerplate-go-fiber/repository/users"

	"github.com/sirupsen/logrus"
)

type Repo struct {
	//Role    role.RoleRepo
	Product  product.ProductRepo
	Contents contents.ContentsRepo
	Users    users.UsersRepo
}

func NewRepo(db *infra.DatabaseList, logger *logrus.Logger) Repo {
	return Repo{
		//Role:    role.NewMasterRepo(db, logger),
		Product:  product.NewMasterRepo(db, logger),
		Contents: contents.NewMasterRepo(db, logger),
		Users:    users.NewMasterRepo(db, logger),
	}
}
