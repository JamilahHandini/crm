package routes

import (
	"boilerplate-go-fiber/domain/general"
	"boilerplate-go-fiber/handler"
	"boilerplate-go-fiber/middleware"

	"github.com/gofiber/fiber/v2"
	"github.com/sirupsen/logrus"
)

func getContents(api fiber.Router, handler handler.Handler, conf *general.SectionService, log *logrus.Logger) {
	api.Get("/contents/search", middleware.CMSJWTValidator(conf, log), handler.Core.Contents.Contents.GetAll)
	api.Post("/contents/getlist", middleware.CMSJWTValidator(conf, log), handler.Core.Contents.Contents.GetListByPage)
}
