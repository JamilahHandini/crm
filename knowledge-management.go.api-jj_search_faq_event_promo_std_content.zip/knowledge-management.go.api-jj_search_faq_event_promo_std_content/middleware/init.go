package middleware

import (
	"boilerplate-go-fiber/domain/general"

	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/fiber/v2/middleware/cors"
	"github.com/gofiber/fiber/v2/middleware/recover"
	"github.com/sirupsen/logrus"
)

func GeneralMiddleware(app *fiber.App, conf *general.SectionService, log *logrus.Logger) {

	//* CORS
	app.Use(cors.New(cors.Config{
		AllowHeaders: conf.Route.Headers,
		AllowMethods: conf.Route.Methods,
		AllowOrigins: "*",
	}))
	app.Use(recover.New())
}
