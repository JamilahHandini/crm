package product

type ProductData struct {
	Productcode *string `json:"productcode" db:"product_code"`
	Productname *string `json:"productname" db:"product_name"`
}

type ListProduct struct {
	Productcode *string `json:"productcode" db:"product_code"`
	Productname *string `json:"productname" db:"product_name"`
}
