package infra

import (
	"github.com/ic2hrmk/lokigrus"
	"github.com/sirupsen/logrus"
)

func InitPromtailSupport(logger *logrus.Logger, lokiAddress string, appLabels map[string]string) error {
	promtailHook, err := lokigrus.NewPromtailHook(lokiAddress, appLabels)
	if err != nil {
		return err
	}
	logger.AddHook(promtailHook)
	return nil
}
