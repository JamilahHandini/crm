package product

import (
	dr "boilerplate-go-fiber/domain/product"
	"boilerplate-go-fiber/infra"

	"github.com/sirupsen/logrus"
)

type ProductDataRepo struct {
	DBList *infra.DatabaseList
	Log    *logrus.Logger
}

func newProductDataRepo(dbList *infra.DatabaseList, logger *logrus.Logger) ProductDataRepo {
	return ProductDataRepo{
		DBList: dbList,
		Log:    logger,
	}
}

const (
	uqGetAllProduct = `
	SELECT product_code, product_name 
	FROM product;
	`
)

type ProductDataRepoItf interface {
	// CreateProduct(ctx context.Context, arg dr.CreateRoleParam) (error, *dr.CreateRoleScan)
	// GetProducByProductId(ctx context.Context, roleId int64) (error, *dr.GetRoleScan)
	// GetProductByProductName(ctx context.Context, roleName string) (error, *dr.GetRoleScan)
	GetAllProduct() ([]dr.ListProduct, error)
	// ListProductWithLimit(ctx context.Context, page int, pageSize int) (error, *[]dr.ListRoleScan, int)
	// UpdateProduct(ctx context.Context, arg dr.UpdateRoleParam) (error, *dr.UpdateRoleScan)
}

func (ur ProductDataRepo) GetAllProduct() ([]dr.ListProduct, error) {
	var result []dr.ListProduct

	q := uqGetAllProduct
	query, args, err := ur.DBList.LOCALPOSTGREESQLDB.Read.In(q)
	ur.Log.Info("test ")
	if err != nil {
		return nil, err
	}

	query = ur.DBList.LOCALPOSTGREESQLDB.Read.Rebind(query)
	err = ur.DBList.LOCALPOSTGREESQLDB.Read.Select(&result, query, args...)
	ur.Log.Info(err)
	if err != nil {
		return result, err
	}

	return result, nil
}
