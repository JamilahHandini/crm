package general

const (
	PageDefault  int    = 1
	LimitDefault int    = 10
	SortDefault  string = "ASC"
)
