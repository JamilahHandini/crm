package users

import (
	dr "boilerplate-go-fiber/domain/users"
	"boilerplate-go-fiber/infra"
	"database/sql"

	"github.com/sirupsen/logrus"
)

type UsersDataRepo struct {
	DBList *infra.DatabaseList
	Log    *logrus.Logger
}

func newUsersDataRepo(dbList *infra.DatabaseList, logger *logrus.Logger) UsersDataRepo {
	return UsersDataRepo{
		DBList: dbList,
		Log:    logger,
	}
}

const (
	//queryCheckLogin = `select id,email,password,username from up_users where email = ? and password = ?
	queryCheckLogin = `select id,email,password,username from up_users where email = ?
	
	`
)

type UsersDataRepoItf interface {
	CheckLoginUser(data dr.LoginUserRequest) (*dr.UserData, error)

	// CreateProduct(ctx context.Context, arg dr.CreateRoleParam) (error, *dr.CreateRoleScan)
	// GetProducByProductId(ctx context.Context, roleId int64) (error, *dr.GetRoleScan)
	// GetProductByProductName(ctx context.Context, roleName string) (error, *dr.GetRoleScan)
	//GetAllProduct() ([]dr.ContentsData, error)
	// ListProductWithLimit(ctx context.Context, page int, pageSize int) (error, *[]dr.ListRoleScan, int)
	// UpdateProduct(ctx context.Context, arg dr.UpdateRoleParam) (error, *dr.UpdateRoleScan)
}

func (ur UsersDataRepo) CheckLoginUser(data dr.LoginUserRequest) (*dr.UserData, error) {
	var res dr.UserData

	q := queryCheckLogin

	param := make([]interface{}, 0)

	param = append(param, data.Email)
	//	param = append(param, data.Password)

	query, args, err := ur.DBList.KNOWLEDGEMANAGEMENTDB.Read.In(q, param)
	ur.Log.Info("test ")
	if err != nil {
		return nil, err
	}

	query = ur.DBList.KNOWLEDGEMANAGEMENTDB.Read.Rebind(query)
	err = ur.DBList.KNOWLEDGEMANAGEMENTDB.Read.Get(&res, query, args...)
	ur.Log.Info(err)
	if err != nil && err != sql.ErrNoRows {
		return nil, err
	}

	return &res, nil
}
