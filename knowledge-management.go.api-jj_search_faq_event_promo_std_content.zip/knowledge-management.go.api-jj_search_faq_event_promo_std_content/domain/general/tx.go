package general

import (
	"context"
	"database/sql"

	"github.com/sirupsen/logrus"
)

type InitTx struct {
	Ctx  context.Context
	Conf *SectionService
	DB   *sql.DB
	Log  *logrus.Logger
}
