package auth

type LoginRequest struct {
	Upn         string `json:"upn"`
	Name        string `json:"name"`
	AccessToken string `json:"access_token"`
}

type LoginResponse struct {
	AccessId int64 `json:""`
}
