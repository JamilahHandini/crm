package users

import (
	"boilerplate-go-fiber/domain/general"
	dt "boilerplate-go-fiber/domain/users"
	"boilerplate-go-fiber/exception"
	"boilerplate-go-fiber/usecase"

	uu "boilerplate-go-fiber/usecase/users"

	"github.com/gofiber/fiber/v2"
	"github.com/sirupsen/logrus"
)

type UsersDataHandler struct {
	Usecase uu.UsersDataUsecaseItf
	conf    *general.SectionService
	log     *logrus.Logger
}

func newUsersHandler(uc usecase.Usecase, conf *general.SectionService, logger *logrus.Logger) UsersDataHandler {
	return UsersDataHandler{
		Usecase: uc.Users.Users,
		conf:    conf,
		log:     logger,
	}
}

func (th UsersDataHandler) Login(c *fiber.Ctx) error {

	th.log.Info("Login ==>")

	initException := exception.InitException(c, th.conf, th.log)

	// authorizationHeader := c.Get("Authorization")
	// if !strings.Contains(authorizationHeader, "Bearer") {
	// 	return exception.CreateResponse_Log(initException, fiber.StatusUnauthorized, "Invalid Token Format", "Invalid Token Format", nil)
	// }
	// accessToken := strings.Replace(authorizationHeader, "Bearer ", "", -1)

	//* Insert Data to datareq struct
	var payload dt.LoginUserRequest
	if err := c.BodyParser(&payload); err != nil {
		return exception.CreateResponse_Log(initException, fiber.StatusBadRequest, "Error Parse Body", "Error Parse Body", nil)
	}

	//* Usecase
	jwtCMSUser, errData := th.Usecase.GetToken(payload)
	if errData != nil {
		return exception.CreateResponse_Log(initException, errData.Code, errData.Message, errData.MessageInd, nil)
	}

	c.Cookie(&fiber.Cookie{
		Name:     th.conf.Cookie.CMSAT,
		Value:    jwtCMSUser.AccessToken,
		HTTPOnly: true,
		Secure:   true,
		Expires:  *jwtCMSUser.Expired,
		Domain:   th.conf.Cookie.CMSDomain,
	})

	// c.Cookie(&fiber.Cookie{
	// 	Name:     th.conf.Cookie.CMSRT,
	// 	//Value:    jwtCMSUser.RefreshToken,
	// 	HTTPOnly: true,
	// 	Secure:   true,
	// 	Expires:  *jwtCMSUser.RTExpired,
	// 	Domain:   th.conf.Cookie.CMSDomain,
	// })

	// c.Cookie(&fiber.Cookie{
	// 	Name:     th.conf.Cookie.CMSSigned,
	// 	Value:    "true",
	// 	HTTPOnly: false,
	// 	Secure:   true,
	// 	Expires:  *jwtCMSUser.RTExpired,
	// 	Domain:   th.conf.Cookie.CMSDomain,
	// })

	return exception.CreateResponse_Log(initException, fiber.StatusOK, "Success", "Sukses", jwtCMSUser)
}
