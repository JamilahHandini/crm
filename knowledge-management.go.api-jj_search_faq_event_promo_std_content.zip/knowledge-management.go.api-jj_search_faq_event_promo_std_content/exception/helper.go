package exception

import "boilerplate-go-fiber/domain/general"

func NewError(code int, message string, messageInd string) *general.Error {
	return &general.Error{
		Code:       code,
		Message:    message,
		MessageInd: messageInd,
	}
}
