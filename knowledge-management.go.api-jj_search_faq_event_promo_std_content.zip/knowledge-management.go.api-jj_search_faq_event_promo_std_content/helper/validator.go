package helper

import (
	"boilerplate-go-fiber/domain/general"
	"boilerplate-go-fiber/exception"
	"fmt"
	"strings"

	"github.com/go-playground/validator/v10"
	"github.com/gofiber/fiber/v2"
)

func ValidateDataRequest(dataReq interface{}) *general.Error {
	//* Validate data request
	validate := validator.New()
	err := validate.Struct(dataReq)
	if err != nil {
		if strings.Contains(err.Error(), "failed on the 'required' tag") {
			field := between(err.Error(), "Field validation for ", " failed on the 'required")
			errMsg := fmt.Sprintf("Data %s cannot be empty", field)
			errMsgInd := fmt.Sprintf("Data %s tidak boleh kosong", field)
			return exception.NewError(fiber.StatusBadRequest, errMsg, errMsgInd)
		} else {
			return exception.NewError(fiber.StatusBadRequest, err.Error(), err.Error())
		}
	}
	return nil
}

func between(value string, a string, b string) string {
	// Get substring between two strings.
	posFirst := strings.Index(value, a)
	if posFirst == -1 {
		return ""
	}
	posLast := strings.Index(value, b)
	if posLast == -1 {
		return ""
	}
	posFirstAdjusted := posFirst + len(a)
	if posFirstAdjusted >= posLast {
		return ""
	}
	return value[posFirstAdjusted:posLast]
}
