package main

import (
	"boilerplate-go-fiber/cmd/core/config"
	"boilerplate-go-fiber/cmd/core/routes"
	"boilerplate-go-fiber/helper"
	"boilerplate-go-fiber/middleware"
	"boilerplate-go-fiber/utils"
	"fmt"

	"github.com/gofiber/fiber/v2"
	"github.com/gofiber/template/html"
)

func main() {

	//* Get Config
	conf, err := config.GetCoreConfig()
	if err != nil {
		panic(err)
	}
	handler, log, err := config.NewRepoContext(conf)
	helper.PanicIfError(err)

	//* Initial JWT config
	utils.InitJWTConfig(conf.Authorization.JWT)

	//* Initial Engine
	engine := html.New("./views", ".html")

	//* Initial Fiber App
	app := fiber.New(fiber.Config{
		AppName:      conf.App.Name,
		ServerHeader: "Go Fiber",
		Views:        engine,
		BodyLimit:    conf.App.BodyLimit * 1024 * 1024,
	})

	//* Use general middleware
	middleware.GeneralMiddleware(app, conf, log)

	//* Initial Routes
	routes.SetupRoutes(app, handler, conf, log)

	log.Fatal(app.Listen(fmt.Sprintf(":%s", conf.App.Port)))
}
