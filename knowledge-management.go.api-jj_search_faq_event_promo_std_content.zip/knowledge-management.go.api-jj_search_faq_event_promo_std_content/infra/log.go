package infra

import (
	constants "boilerplate-go-fiber/constants/general"
	"boilerplate-go-fiber/domain/general"

	"fmt"

	"github.com/sirupsen/logrus"
	easy "github.com/t-tomalak/logrus-easy-formatter"
)

var logger *logrus.Logger

func NewLogger(conf *general.SectionService) *logrus.Logger {
	if logger == nil {
		logger = logrus.New()
		logger.SetFormatter(&easy.Formatter{
			TimestampFormat: constants.FullTimeFormat,
			LogFormat:       fmt.Sprintf("%s\n", `[%lvl%]: "%time%" %msg%`),
		})
		logger.SetLevel(logrus.InfoLevel)
		return logger
	}
	return logger
}
