DROP TABLE IF EXISTS transaction_detail;
DROP TABLE IF EXISTS product;
DROP TABLE IF EXISTS transaction;
DROP TABLE IF EXISTS "user";
DROP TABLE IF EXISTS role;

CREATE TABLE "user" (
  "user_id" bigserial PRIMARY KEY,
  "username" varchar(250) NOT NULL,
  "name" varchar(250) NOT NULL,
  "password" varchar NOT NULL,
  "address" text NOT NULL,
  "role_id" bigint,
  "token" text,
  "created_by" varchar(250),
  "created_at" timestamptz NOT NULL DEFAULT (now()),
  "updated_by" varchar(250),
  "updated_at" timestamptz,
  "is_active" bool
);

CREATE TABLE "role" (
  "role_id" bigserial PRIMARY KEY,
  "role_name" varchar(250) NOT NULL,
  "created_by" varchar(250),
  "created_at" timestamptz NOT NULL DEFAULT (now()),
  "updated_by" varchar(250),
  "updated_at" timestamptz,
  "is_active" bool
);

CREATE TABLE "product" (
  "product_id" bigserial PRIMARY KEY,
  "product_name" varchar(250) NOT NULL,
  "price" double precision NOT NULL,
  "img_url" text,
  "created_by" varchar(250),
  "created_at" timestamptz NOT NULL DEFAULT (now()),
  "updated_by" varchar(250),
  "updated_at" timestamptz,
  "is_active" bool
);

CREATE TABLE "transaction" (
  "transaction_id" bigserial PRIMARY KEY,
  "user_id" bigint NOT NULL,
  "total_price" double precision NOT NULL,
  "created_by" varchar(250),
  "created_at" timestamptz NOT NULL DEFAULT (now()),
  "updated_by" varchar(250),
  "updated_at" timestamptz
);

CREATE TABLE "transaction_detail" (
  "transaction_detail_id" bigserial PRIMARY KEY,
  "transaction_id" bigint NOT NULL,
  "product_id" bigint NOT NULL,
  "created_by" varchar(250),
  "created_at" timestamptz NOT NULL DEFAULT (now()),
  "updated_by" varchar(250),
  "updated_at" timestamptz
);

CREATE INDEX ON "user" ("username");

CREATE INDEX ON "user" ("name");

CREATE INDEX ON "user" ("is_active");

CREATE INDEX ON "role" ("role_name");

CREATE INDEX ON "role" ("is_active");

CREATE INDEX ON "product" ("product_name");

CREATE INDEX ON "product" ("is_active");

CREATE INDEX ON "transaction" ("user_id");

ALTER TABLE "user" ADD FOREIGN KEY ("role_id") REFERENCES "role" ("role_id");

ALTER TABLE "transaction" ADD FOREIGN KEY ("user_id") REFERENCES "user" ("user_id");

ALTER TABLE "transaction_detail" ADD FOREIGN KEY ("transaction_id") REFERENCES "transaction" ("transaction_id");

ALTER TABLE "transaction_detail" ADD FOREIGN KEY ("product_id") REFERENCES "product" ("product_id");