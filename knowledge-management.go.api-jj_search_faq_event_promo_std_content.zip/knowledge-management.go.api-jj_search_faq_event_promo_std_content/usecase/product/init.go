package product

import (
	"boilerplate-go-fiber/domain/general"
	"boilerplate-go-fiber/infra"
	"boilerplate-go-fiber/repository"

	"github.com/sirupsen/logrus"
)

type ProductUsecase struct {
	Product ProductDataUsecaseItf
}

func NewUsecase(repo repository.Repo, conf *general.SectionService, dbList *infra.DatabaseList, logger *logrus.Logger) ProductUsecase {
	return ProductUsecase{
		Product: newProductDataUsecase(repo, conf, logger, dbList),
	}
}
