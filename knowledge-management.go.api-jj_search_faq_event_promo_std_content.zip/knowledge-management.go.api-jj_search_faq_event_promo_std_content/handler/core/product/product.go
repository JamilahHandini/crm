package product

import (
	"boilerplate-go-fiber/domain/general"
	"boilerplate-go-fiber/exception"
	"boilerplate-go-fiber/usecase"

	"github.com/gofiber/fiber/v2"
	"github.com/sirupsen/logrus"

	uu "boilerplate-go-fiber/usecase/product"
)

type ProductDataHandler struct {
	Usecase uu.ProductDataUsecaseItf
	conf    *general.SectionService
	log     *logrus.Logger
}

func newProductHandler(uc usecase.Usecase, conf *general.SectionService, logger *logrus.Logger) ProductDataHandler {
	return ProductDataHandler{
		Usecase: uc.Product.Product,
		conf:    conf,
		log:     logger,
	}
}

func (th ProductDataHandler) GetAll(c *fiber.Ctx) error {

	th.log.Info("Get ALL coba ==>")

	initException := exception.InitException(c, th.conf, th.log)

	//* Usecase
	GetAllProduct, errData := th.Usecase.GetAllProduct()
	if errData != nil {
		return exception.CreateResponse_Log(initException, errData.Code, errData.Message, errData.MessageInd, nil)
	}

	return exception.CreateResponse_Log(initException, fiber.StatusOK, "Success", "Sukses", GetAllProduct)
}
