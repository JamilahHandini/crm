package config

import (
	"boilerplate-go-fiber/domain/general"
	h "boilerplate-go-fiber/handler"
	"boilerplate-go-fiber/infra"
	"boilerplate-go-fiber/repository"
	"boilerplate-go-fiber/usecase"

	"github.com/sirupsen/logrus"
)

func NewRepoContext(conf *general.SectionService) (h.Handler, *logrus.Logger, error) {
	var handler h.Handler

	//* Init Log
	logger := infra.NewLogger(conf)

	dbKNOWLEDGEMANAGEMENTDBRead := infra.NewDB(logger)
	dbKNOWLEDGEMANAGEMENTDBRead.ConnectDatabase(conf.ConnectionDB.KNOWLEDGEMANAGEMENTDB.DriverName, conf.ConnectionDB.KNOWLEDGEMANAGEMENTDB.DriverSource, conf.ConnectionDB.KNOWLEDGEMANAGEMENTDB.MaxLifeTime)
	if dbKNOWLEDGEMANAGEMENTDBRead.Err != nil {
		return handler, logger, dbKNOWLEDGEMANAGEMENTDBRead.Err
	}

	// Init DB Write Connection.
	dbKNOWLEDGEMANAGEMENTDBWrite := infra.NewDB(logger)
	dbKNOWLEDGEMANAGEMENTDBWrite.ConnectDatabase(conf.ConnectionDB.KNOWLEDGEMANAGEMENTDB.DriverName, conf.ConnectionDB.KNOWLEDGEMANAGEMENTDB.DriverSource, conf.ConnectionDB.KNOWLEDGEMANAGEMENTDB.MaxLifeTime)
	if dbKNOWLEDGEMANAGEMENTDBWrite.Err != nil {
		return handler, logger, dbKNOWLEDGEMANAGEMENTDBWrite.Err
	}

	// Init DB Read Connection.
	// dbLOCALSQLSERVERDBRead := infra.NewDB(logger)
	// dbLOCALSQLSERVERDBRead.ConnectDatabase(conf.ConnectionDB.LOCALSQLSERVERDB.DriverName, conf.ConnectionDB.LOCALSQLSERVERDB.DriverSource, conf.ConnectionDB.LOCALSQLSERVERDB.MaxLifeTime)
	// if dbLOCALSQLSERVERDBRead.Err != nil {
	// 	return handler, logger, dbLOCALSQLSERVERDBRead.Err
	// }

	// // Init DB Write Connection.
	// dbLOCALSQLSERVERDBWrite := infra.NewDB(logger)
	// dbLOCALSQLSERVERDBWrite.ConnectDatabase(conf.ConnectionDB.LOCALSQLSERVERDB.DriverName, conf.ConnectionDB.LOCALSQLSERVERDB.DriverSource, conf.ConnectionDB.LOCALSQLSERVERDB.MaxLifeTime)
	// if dbLOCALSQLSERVERDBWrite.Err != nil {
	// 	return handler, logger, dbLOCALSQLSERVERDBWrite.Err
	// }

	// pgconn := general.DBDetailAccount{
	// 	Username:     conf.Database.Username,
	// 	Password:     conf.Database.Password,
	// 	URL:          conf.Database.URL,
	// 	Port:         conf.Database.Port,
	// 	DBName:       conf.Database.DBName,
	// 	SSLMode:      conf.Database.SSLMode,
	// 	TimeZone:     conf.Database.TimeZone,
	// 	MaxIdleConns: 5,
	// 	MaxOpenConns: 20,
	// 	MaxLifeTime:  60,
	// 	Timeout:      "10000",
	// }

	// logger.Info(pgconn)
	// // Init DB Read Connection.
	// dbLOCALPOSTGREESQLDBRead := infra.NewDB(logger)
	// //dbLOCALPOSTGREESQLDBRead.ConnectDB(conf.ConnectionDB.LOCALPOSTGREESQLDB.DriverName, conf.ConnectionDB.LOCALPOSTGREESQLDB.DriverSource, conf.ConnectionDB.LOCALPOSTGREESQLDB.MaxLifeTime)
	// dbLOCALPOSTGREESQLDBRead.ConnectDB(&pgconn)
	// if dbLOCALPOSTGREESQLDBRead.Err != nil {
	// 	return handler, logger, dbLOCALPOSTGREESQLDBRead.Err
	// }

	// Init DB Write Connection.
	dbLOCALPOSTGREESQLWrite := infra.NewDB(logger)
	//dbLOCALPOSTGREESQLWrite.ConnectDatabase(conf.ConnectionDB.LOCALPOSTGREESQLDB.DriverName, conf.ConnectionDB.LOCALPOSTGREESQLDB.DriverSource, conf.ConnectionDB.LOCALPOSTGREESQLDB.MaxLifeTime)
	dbKNOWLEDGEMANAGEMENTDBWrite.ConnectDatabase(conf.ConnectionDB.KNOWLEDGEMANAGEMENTDB.DriverName, conf.ConnectionDB.KNOWLEDGEMANAGEMENTDB.DriverSource, conf.ConnectionDB.KNOWLEDGEMANAGEMENTDB.MaxLifeTime)
	if dbLOCALPOSTGREESQLWrite.Err != nil {
		return handler, logger, dbLOCALPOSTGREESQLWrite.Err
	}

	dbList := &infra.DatabaseList{
		// LOCALSQLSERVERDB: infra.DatabaseType{
		// 	Read:  &dbLOCALSQLSERVERDBRead,
		// 	Write: &dbLOCALSQLSERVERDBWrite,
		// },
		// LOCALPOSTGREESQLDB: infra.DatabaseType{
		// 	Read:  &dbLOCALPOSTGREESQLDBRead,
		// 	Write: &dbLOCALPOSTGREESQLWrite,
		// },
		KNOWLEDGEMANAGEMENTDB: infra.DatabaseType{
			Read:  &dbKNOWLEDGEMANAGEMENTDBRead,
			Write: &dbKNOWLEDGEMANAGEMENTDBWrite,
		},
	}

	repo := repository.NewRepo(dbList, logger)
	usecase := usecase.NewUsecase(repo, conf, dbList, logger)
	handler = h.NewHandler(usecase, conf, logger)

	return handler, logger, nil
}
