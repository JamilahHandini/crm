package usecase

import (
	"boilerplate-go-fiber/domain/general"
	"boilerplate-go-fiber/infra"
	"boilerplate-go-fiber/repository"

	"boilerplate-go-fiber/usecase/contents"
	"boilerplate-go-fiber/usecase/product"
	"boilerplate-go-fiber/usecase/role"
	"boilerplate-go-fiber/usecase/users"

	"github.com/sirupsen/logrus"
)

type Usecase struct {
	Role    role.RoleUsecase
	Product product.ProductUsecase
	Content contents.ContentsUsecase
	Users   users.UsersUsecase
}

// func NewUsecase(repo repository.Repo, conf *general.SectionService, db *sql.DB, logger *logrus.Logger) Usecase {
// 	return Usecase{
// 		Role:    role.NewUsecase(repo, conf, db, logger),
// 		Product: product.NewUsecase(repo, conf, db, logger),
// 	}
// }

func NewUsecase(repo repository.Repo, conf *general.SectionService, dbList *infra.DatabaseList, logger *logrus.Logger) Usecase {
	return Usecase{
		//Role:    role.NewUsecase(repo, conf, dbList, logger),
		Product: product.NewUsecase(repo, conf, dbList, logger),
		Content: contents.NewUsecase(repo, conf, dbList, logger),
		Users:   users.NewUsecase(repo, conf, dbList, logger),
	}
}
