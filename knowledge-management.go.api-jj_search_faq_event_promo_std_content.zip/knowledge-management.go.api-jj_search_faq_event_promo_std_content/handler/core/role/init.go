package role

import (
	"boilerplate-go-fiber/domain/general"
	"boilerplate-go-fiber/usecase"

	"github.com/sirupsen/logrus"
)

type RoleHandler struct {
	Role RoleDataHandler
}

func NewCoreHandler(uc usecase.Usecase, conf *general.SectionService, logger *logrus.Logger) RoleHandler {
	return RoleHandler{
		Role: newRoleHandler(uc, conf, logger),
	}
}
