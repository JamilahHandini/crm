package utils

import (
	"regexp"
	"strings"
)

func IsEmail(e string) bool {
	val := regexp.MustCompile(`^[a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,4}$`)
	return val.MatchString(e)
}

func IsPhoneNo(s string) bool {
	val := regexp.MustCompile(`^\+?(\d[\d-. ]+)?(\([\d-. ]+\))?[\d-. ]+\d$`)
	return val.MatchString(s)
}

func IsNumeric(s string) bool {
	val := regexp.MustCompile(`^[0-9\s,]*$`)
	return val.MatchString(s)
}

func IsNilOrEmpty(data *string) bool {
	return data == nil || strings.TrimSpace(*data) == ""
}
