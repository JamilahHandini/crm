package utils

import (
	"fmt"
	"time"

	dg "boilerplate-go-fiber/domain/general"

	jwt "github.com/dgrijalva/jwt-go"
)

const (
	issuer = "Backend CRM"
)

var jwtCfg JWT

type JWT struct {
	atSecretKey []byte        //* Access Token Secret Key
	atd         time.Duration //* Access Token Duration
}

type Claims struct {
	jwt.StandardClaims
	Session    string `json:"session"`
	Renew      string `json:"renew,omitempty"`
	Channel    string `json:"channel"`
	EmployeeID string `json:"employeeid"`
	UserID     int64  `json:"userid"`
	Username   string `json:"username"`
	CabangID   string `json:"cabangid"`
}

func InitJWTConfig(cfg dg.JWTCredential) {
	jwtCfg = JWT{
		atSecretKey: []byte(cfg.AccessTokenSecretKey),
		atd:         time.Duration(cfg.AccessTokenDuration) * time.Minute,
	}
}

func GenerateJWTCMSWithClaims(session string, userID int64, username string) (string, *time.Time, error) {
	//* Create Access Token
	accessToken, expiredTime, err := generateAccessTokenWithClaims(session, "KnowledgeManagementCMS", "", userID, username, "")
	if err != nil {
		return "", nil, err
	}

	// Create Refresh Token
	// refreshToken, rtExpiredTime, err := generateRefreshTokenWithClaims(session, "MAECMS", "", userID, username, "")
	// if err != nil {
	// 	return "", "", nil, nil, err
	// }

	// return accessToken, refreshToken, nil
	//return accessToken, refreshToken, expiredTime, rtExpiredTime, nil
	return accessToken, expiredTime, nil
}

func generateAccessTokenWithClaims(session string, channel string, employeeID string, userID int64, username string, cabangid string) (string, *time.Time, error) {
	expired := GenerateTimeNowJakarta().Add(jwtCfg.atd)

	accessClaims := Claims{
		StandardClaims: jwt.StandardClaims{
			Issuer:    issuer,
			ExpiresAt: expired.Unix(),
		},
		Session:    session,
		Channel:    channel,
		EmployeeID: employeeID,
		CabangID:   cabangid,
		UserID:     userID,
		Username:   username,
	}
	accessToken := jwt.NewWithClaims(jwt.SigningMethodHS256, accessClaims)
	accessSignedToken, err := accessToken.SignedString(jwtCfg.atSecretKey)
	if err != nil {
		return "", nil, err
	}
	return accessSignedToken, &expired, nil
}

// * GenerateJWT will generate Access Token & Refresh Token
// * Use this when login authentication is success
func GenerateJWT(session string) (string, string, error) {
	//* Create Access Token
	accessToken, expiredTime, err := generateAccessToken(session)
	if err != nil {
		return "", "", err
	}
	return accessToken, fmt.Sprintf("%s", expiredTime), nil
}

func generateAccessToken(session string) (string, *time.Time, error) {

	expired := GenerateTimeNowJakarta().Add(jwtCfg.atd)

	accessClaims := Claims{
		StandardClaims: jwt.StandardClaims{
			Issuer:    issuer,
			ExpiresAt: expired.Unix(),
		},
		Session: session,
	}
	accessToken := jwt.NewWithClaims(jwt.SigningMethodHS256, accessClaims)
	accessSignedToken, err := accessToken.SignedString(jwtCfg.atSecretKey)
	if err != nil {
		return "", nil, err
	}
	return accessSignedToken, &expired, nil
}

// * CheckAccessToken will check validity of access_token
// * This action will be used in middleware
func CheckAccessToken(tokenString string) (jwt.MapClaims, error) {
	token, err := jwt.Parse(tokenString, func(token *jwt.Token) (interface{}, error) {
		if _, ok := token.Method.(*jwt.SigningMethodHMAC); !ok {
			return nil, fmt.Errorf("Signing method invalid")
		}

		return jwtCfg.atSecretKey, nil
	})
	if err != nil {
		return nil, err
	}

	claims, ok := token.Claims.(jwt.MapClaims)
	if !ok || !token.Valid {
		return nil, fmt.Errorf("Invalid Token")
	}

	isr := fmt.Sprintf("%v", claims["iss"])
	if isr != issuer {
		return nil, fmt.Errorf("Invalid Issuer")
	}

	return claims, nil
}

func CheckOneKalbeAccessToken(tokenString string) (jwt.MapClaims, error) {
	token, err := jwt.Parse(tokenString, func(token *jwt.Token) (interface{}, error) {
		if _, ok := token.Method.(*jwt.SigningMethodHMAC); !ok {
			return nil, fmt.Errorf("Signing method invalid")
		}

		return jwtCfg.atSecretKey, nil
	})
	if err != nil {
		return nil, err
	}

	claims, ok := token.Claims.(jwt.MapClaims)
	if !ok || !token.Valid {
		return nil, fmt.Errorf("Invalid Token")
	}

	isr := fmt.Sprintf("%v", claims["iss"])
	if isr != issuer {
		return nil, fmt.Errorf("Invalid Issuer")
	}

	return claims, nil
}
