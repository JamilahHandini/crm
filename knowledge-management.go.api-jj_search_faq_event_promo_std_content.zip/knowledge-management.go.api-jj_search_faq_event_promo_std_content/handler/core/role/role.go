package role

import (
	"boilerplate-go-fiber/domain/general"
	dr "boilerplate-go-fiber/domain/role"
	"boilerplate-go-fiber/exception"
	"boilerplate-go-fiber/usecase"
	ru "boilerplate-go-fiber/usecase/role"
	"fmt"
	"strconv"

	"github.com/gofiber/fiber/v2"
	"github.com/sirupsen/logrus"
)

type RoleDataHandler struct {
	Usecase ru.RoleDataUsecaseItf
	conf    *general.SectionService
	log     *logrus.Logger
}

func newRoleHandler(uc usecase.Usecase, conf *general.SectionService, logger *logrus.Logger) RoleDataHandler {
	return RoleDataHandler{
		Usecase: uc.Role.Role,
		conf:    conf,
		log:     logger,
	}
}

func (ch RoleDataHandler) CreateRole(c *fiber.Ctx) error {

	init := exception.InitException(c, ch.conf, ch.log)

	//* Get Data
	dataReq := new(dr.CreateRoleRequest)
	err := c.BodyParser(dataReq)
	if err != nil {
		return exception.CreateResponse_Log(init, fiber.StatusBadRequest, "Please check your input!", "Tolong periksa input anda!", nil)
	}
	name := fmt.Sprintf("%v", c.Locals("name"))

	//* Usecase
	errData, respData := ch.Usecase.CreateRole(c.UserContext(), dataReq, name)
	if errData != nil {
		return exception.CreateResponse_Log(init, errData.Code, errData.Message, errData.MessageInd, nil)
	}

	//* Create Response
	return exception.CreateResponse_Log(init, fiber.StatusOK, "Success create role", "Sukses membuat role", respData)
}

func (ch RoleDataHandler) FindByRoleId(c *fiber.Ctx) error {

	init := exception.InitException(c, ch.conf, ch.log)

	//* Get Data
	roleId, err := strconv.Atoi(c.Query("roleId"))
	if err != nil {
		return exception.CreateResponse_Log(init, fiber.StatusBadRequest, "Make sure 'id' is integer ", "Pastikan value dari 'id' adalah bilangan bulat !", nil)
	}

	//* Usecase
	errData, respData := ch.Usecase.GetByRoleId(c.UserContext(), int64(roleId))
	if errData != nil {
		return exception.CreateResponse_Log(init, errData.Code, errData.Message, errData.MessageInd, nil)
	}

	//* Create Response
	return exception.CreateResponse_Log(init, fiber.StatusOK, "Success find role", "Sukses find role", respData)
}

func (ch RoleDataHandler) FindByRoleName(c *fiber.Ctx) error {

	init := exception.InitException(c, ch.conf, ch.log)

	//* Get Data
	roleName := c.Query("roleName")

	//* Usecase
	errData, respData := ch.Usecase.GetByRoleName(c.UserContext(), roleName)
	if errData != nil {
		return exception.CreateResponse_Log(init, errData.Code, errData.Message, errData.MessageInd, nil)
	}

	//* Create Response
	return exception.CreateResponse_Log(init, fiber.StatusOK, "Success find role", "Sukses find role", respData)
}

func (ch RoleDataHandler) ListRole(c *fiber.Ctx) error {

	init := exception.InitException(c, ch.conf, ch.log)

	//* Get data
	page, err := strconv.Atoi(c.Query("page", "1"))
	if err != nil {
		return exception.CreateResponse_Log(init, fiber.StatusBadRequest, "Make sure 'id' is integer ", "Pastikan value dari 'id' adalah bilangan bulat !", nil)
	}
	pageSize, err := strconv.Atoi(c.Query("pageSize", "0"))
	if err != nil {
		return exception.CreateResponse_Log(init, fiber.StatusBadRequest, "Make sure 'id' is integer ", "Pastikan value dari 'id' adalah bilangan bulat !", nil)
	}

	//* Usecase
	errData, respData, total, lastPage := ch.Usecase.ListRole(c.UserContext(), page, pageSize)
	if errData != nil {
		return exception.CreateResponse_Log(init, errData.Code, errData.Message, errData.MessageInd, nil)
	}

	//* Create Response
	return exception.CreateResponse_Log_Page(init, fiber.StatusOK, "Success get list role", "Sukses mendapatkan list role", respData, page, lastPage, total)
}

func (ch RoleDataHandler) UpdateRole(c *fiber.Ctx) error {

	init := exception.InitException(c, ch.conf, ch.log)

	//* Get Data
	dataReq := new(dr.UpdateRoleRequest)
	err := c.BodyParser(dataReq)
	if err != nil {
		return exception.CreateResponse_Log(init, fiber.StatusBadRequest, "Please check your input!", "Tolong periksa input anda!", nil)
	}
	name := fmt.Sprintf("%v", c.Locals("name"))

	//* Usecase
	errData, respData := ch.Usecase.UpdateRole(c.UserContext(), dataReq, name)
	if errData != nil {
		return exception.CreateResponse_Log(init, errData.Code, errData.Message, errData.MessageInd, nil)
	}

	//* Create Response
	return exception.CreateResponse_Log(init, fiber.StatusOK, "Success update role", "Sukses mengupdate role", respData)
}

func (ch RoleDataHandler) UpdateStatusRole(c *fiber.Ctx) error {

	init := exception.InitException(c, ch.conf, ch.log)

	//* Get Data
	dataReq := new(dr.UpdateStatusRoleRequest)
	err := c.BodyParser(dataReq)
	if err != nil {
		return exception.CreateResponse_Log(init, fiber.StatusBadRequest, "Please check your input!", "Tolong periksa input anda!", nil)
	}
	name := fmt.Sprintf("%v", c.Locals("name"))

	//* Usecase
	errData, respData := ch.Usecase.UpdateStatusRole(c.UserContext(), dataReq, name)
	if errData != nil {
		return exception.CreateResponse_Log(init, errData.Code, errData.Message, errData.MessageInd, nil)
	}

	//* Create Response
	return exception.CreateResponse_Log(init, fiber.StatusOK, "Success update status role", "Sukses mengupdate status role", respData)
}
