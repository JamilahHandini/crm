package product

import (
	"boilerplate-go-fiber/infra"

	"github.com/sirupsen/logrus"
)

type ProductRepo struct {
	Product ProductDataRepoItf
}

func NewMasterRepo(db *infra.DatabaseList, logger *logrus.Logger) ProductRepo {
	return ProductRepo{
		Product: newProductDataRepo(db, logger),
	}
}
