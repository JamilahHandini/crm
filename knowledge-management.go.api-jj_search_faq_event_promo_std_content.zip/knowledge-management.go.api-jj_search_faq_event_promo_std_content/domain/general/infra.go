package general

type SectionService struct {
	App           AppAccount          `json:",omitempty"`
	Route         RouteAccount        `json:",omitempty"`
	Database      DatabaseAccount     `json:",omitempty"`
	Authorization AuthAccount         `json:",omitempty"`
	Toggle        ToggleAccount       `json:",omitempty"`
	CloudStorage  CloudStorageAccount `json:",omitempty"`
	ConnectionDB  ConnectionDBAccount `json:",omitempty"`
	Cookie        CookieAccount       `json:",omitempty"`
}

type DBDetailAccount struct {
	Username     string `json:",omitempty"`
	Password     string `json:",omitempty"`
	URL          string `json:",omitempty"`
	Port         string `json:",omitempty"`
	DBName       string `json:",omitempty"`
	SSLMode      string `json:",omitempty"`
	TimeZone     string `json:",omitempty"`
	MaxIdleConns int    `json:",omitempty"`
	MaxOpenConns int    `json:",omitempty"`
	MaxLifeTime  int    `json:",omitempty"`
	Timeout      string `json:",omitempty"`
}

type ConnectionDBAccount struct {
	LOCALSQLSERVERDB      ConnectionDBDetailAccount `json:",omitempty"`
	LOCALPOSTGREESQLDB    ConnectionDBDetailAccount `json:",omitempty"`
	KNOWLEDGEMANAGEMENTDB ConnectionDBDetailAccount `json:",omitempty"`
}

type CookieAccount struct {
	PICDomain     string `json:",omitempty"`
	PICAT         string `json:",omitempty"`
	PICRT         string `json:",omitempty"`
	PICSigned     string `json:",omitempty"`
	CMSDomain     string `json:",omitempty"`
	CMSAT         string `json:",omitempty"`
	CMSRT         string `json:",omitempty"`
	CMSSigned     string `json:",omitempty"`
	PATIENTDomain string `json:",omitempty"`
	PATIENTAT     string `json:",omitempty"`
	PATIENTRT     string `json:",omitempty"`
	PATIENTSigned string `json:",omitempty"`
}

type ConnectionDBDetailAccount struct {
	DriverName   string `json:",omitempty"`
	DriverSource string `json:",omitempty"`
	MaxIdleConns int    `json:",omitempty"`
	MaxOpenConns int    `json:",omitempty"`
	MaxLifeTime  int    `json:",omitempty"`
}

type AppAccount struct {
	Name         string `json:",omitempty"`
	Environtment string `json:",omitempty"`
	URL          string `json:",omitempty"`
	Port         string `json:",omitempty"`
	SecretKey    string `json:",omitempty"`
	Endpoint     string `json:",omitempty"`
	BodyLimit    int    `json:",omitempty"`
}

type RouteAccount struct {
	Methods string      `json:",omitempty"`
	Headers string      `json:",omitempty"`
	Origins RouteOrigin `json:",omitempty"`
}

type RouteOrigin struct {
	Default                     string `json:",omitempty"`
	LoyaltyWebDmqiFeStaging     string `json:",omitempty"`
	LoyaltyWebDmqiFeProd        string `json:",omitempty"`
	DmqiChakraStagingKalbestore string `json:",omitempty"`
	DmqiFeDummy                 string `json:",omitempty"`
	KFREF                       string `json:",omitempty"`
}

type DatabaseAccount struct {
	Username     string `json:",omitempty"`
	Password     string `json:",omitempty"`
	URL          string `json:",omitempty"`
	Port         string `json:",omitempty"`
	DBName       string `json:",omitempty"`
	SSLMode      string `json:",omitempty"`
	TimeZone     string `json:",omitempty"`
	MaxIdleConns int    `json:",omitempty"`
	MaxOpenConns int    `json:",omitempty"`
	MaxLifeTime  int    `json:",omitempty"`
	MaxIdleTime  int    `json:",omitempty"`
}

type AuthAccount struct {
	JWT    JWTCredential    `json:",omitempty"`
	Public PublicCredential `json:",omitempty"`
}

type JWTCredential struct {
	IsActive              bool   `json:",omitempty"`
	AccessTokenSecretKey  string `json:",omitempty"`
	AccessTokenDuration   int    `json:",omitempty"`
	RefreshTokenSecretKey string `json:",omitempty"`
	RefreshTokenDuration  int    `json:",omitempty"`
}

type PublicCredential struct {
	SecretKey string `json:",omitempty"`
}
type ToggleAccount struct {
	IsUseJWT bool `json:",omitempty"`
}

type CloudStorageAccount struct {
	GoogleStorage GoogleStorage `json:",omitempty"`
}

type GoogleStorage struct {
	GoogleCredentialsFile    string `json:",omitempty"`
	GoogleCLoudStorageBucket string `json:",omitempty"`
	GoogleCloudStorageUrl    string `json:",omitempty"`
	AppName                  string `json:",omitempty"`
}
