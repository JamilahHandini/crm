package contents

import (
	dt "boilerplate-go-fiber/domain/contents"
	"boilerplate-go-fiber/domain/general"
	"boilerplate-go-fiber/exception"
	"boilerplate-go-fiber/usecase"

	"github.com/gofiber/fiber/v2"
	"github.com/sirupsen/logrus"

	uu "boilerplate-go-fiber/usecase/contents"
)

type ContentsDataHandler struct {
	Usecase uu.ContentsDataUsecaseItf
	conf    *general.SectionService
	log     *logrus.Logger
}

func newContentsHandler(uc usecase.Usecase, conf *general.SectionService, logger *logrus.Logger) ContentsDataHandler {
	return ContentsDataHandler{
		Usecase: uc.Content.Contents,
		conf:    conf,
		log:     logger,
	}
}

func (th ContentsDataHandler) GetAll(c *fiber.Ctx) error {

	th.log.Info("Get ALL coba ==>")

	initException := exception.InitException(c, th.conf, th.log)

	//* Usecase
	GetAllContents, errData := th.Usecase.GetAllContents()
	if errData != nil {
		return exception.CreateResponse_Log(initException, errData.Code, errData.Message, errData.MessageInd, nil)
	}

	return exception.CreateResponse_Log(initException, fiber.StatusOK, "Success", "Sukses", GetAllContents)
}

func (th ContentsDataHandler) GetListByPage(c *fiber.Ctx) error {

	th.log.Info("Get List Pagging CMS Brand ==>")

	initException := exception.InitException(c, th.conf, th.log)

	var payload dt.ContentListPaggingRequest
	if err := c.BodyParser(&payload); err != nil {
		return exception.CreateResponse_Log(initException, fiber.StatusBadRequest, "Error Parse Body", "Error Parse Body", nil)
	}

	//* Usecase
	getListPagging, errData := th.Usecase.GetListByPage(payload)
	if errData != nil {
		return exception.CreateResponse_Log(initException, errData.Code, errData.Message, errData.MessageInd, nil)
	}

	return exception.CreateResponse_Log(initException, fiber.StatusOK, "Success", "Sukses", getListPagging)
}
