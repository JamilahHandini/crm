package contents

import (
	"boilerplate-go-fiber/infra"

	"github.com/sirupsen/logrus"
)

type ContentsRepo struct {
	Contents ContentsDataRepoItf
}

func NewMasterRepo(db *infra.DatabaseList, logger *logrus.Logger) ContentsRepo {
	return ContentsRepo{
		Contents: newContentsDataRepo(db, logger),
	}
}
