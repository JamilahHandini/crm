package general

import (
	"time"

	"github.com/gofiber/fiber/v2"
	"github.com/sirupsen/logrus"
)

type ResponseData struct {
	RequestId  string             `json:"requestId"`
	Data       interface{}        `json:"data,omitempty"`
	Status     StatusResponseData `json:"status"`
	TimeStamp  time.Time          `json:"timeStamp"`
	Pagination interface{}        `json:"pagination,omitempty"`
}

type Pagination struct {
	Page      int `json:"page,omitempty"`
	LastPage  int `json:"lastPage,omitempty"`
	TotalData int `json:"totalData,omitempty"`
}

type StatusResponseData struct {
	Code       int    `json:"code"`
	Type       string `json:"type"`
	Message    string `json:"message"`
	MessageInd string `json:"messageInd"`
}

type ResponseMessageData struct {
	Message string `json:"message"`
}

type Response interface{}

type Error struct {
	Code       int    `json:"code"`
	Message    string `json:"message"`
	MessageInd string `json:"messageInd"`
}

type InitialExceptionCreateResponse struct {
	Ctx *fiber.Ctx
	Log *logrus.Logger
}
