package contents

import (
	dt "boilerplate-go-fiber/domain/contents"
	"boilerplate-go-fiber/domain/general"
	"boilerplate-go-fiber/exception"
	"boilerplate-go-fiber/infra"
	"boilerplate-go-fiber/repository"
	ru "boilerplate-go-fiber/repository/contents"

	"github.com/gofiber/fiber"
	"github.com/sirupsen/logrus"
)

type ContentsDataUsecaseItf interface {
	GetAllContents() ([]dt.ContentsData, *general.Error)
	GetListByPage(request dt.ContentListPaggingRequest) (*dt.ContentsListPaggingResponse, *general.Error)
	//GetListPagging(pageNumber int, PageSize int, searchKey string) ([]dt.ContentsData, error)
}

type ContentsDataUsecase struct {
	Repo   ru.ContentsDataRepoItf
	DBList *infra.DatabaseList
	Conf   *general.SectionService
	Log    *logrus.Logger
}

func newContentsDataUsecase(r repository.Repo, conf *general.SectionService, logger *logrus.Logger, dbList *infra.DatabaseList) ContentsDataUsecase {
	return ContentsDataUsecase{
		Repo:   r.Contents.Contents,
		Conf:   conf,
		Log:    logger,
		DBList: dbList,
	}
}

func (ut ContentsDataUsecase) GetAllContents() ([]dt.ContentsData, *general.Error) {

	result, err := ut.Repo.GetContents()
	if err != nil {
		ut.Log.Info(err)
		return nil, exception.NewError(fiber.StatusBadRequest, "error get data to DB", "error meminta data ke DB")
	}

	return result, nil
}

func (ut ContentsDataUsecase) GetListByPage(request dt.ContentListPaggingRequest) (*dt.ContentsListPaggingResponse, *general.Error) {
	if request.Pagging.PageNumber < 1 {
		request.Pagging.PageNumber = 1
	}

	// defaultOrderBy := "brandid"
	// if utils.IsNilOrEmpty(request.Pagging.OrderBy) {
	// 	request.Pagging.OrderBy = &defaultOrderBy
	// }

	// defaultOrderType := "ASC"
	// if utils.IsNilOrEmpty(request.Pagging.OrderType) {
	// 	request.Pagging.OrderBy = &defaultOrderType
	// }

	getListPagging, err := ut.Repo.GetListByPage(request)
	if err != nil {
		ut.Log.Info(err)
		return nil, exception.NewError(fiber.StatusBadRequest, "error get data to DB. "+err.Error()+".", "error meminta data ke DB. "+err.Error()+".")
		//return nil, exception.NewError(fiber.StatusBadRequest, "error get data to DB", "error meminta data ke DB")
	}

	var getListPaggingResponse []dt.ContentsData
	totalRow := 0
	//isNext := false

	for _, v := range getListPagging {
		var contents dt.ContentsData
		contents.Rowno = v.Rowno
		contents.Id = v.Id
		contents.Description = v.Description
		contents.Title = v.Title
		contents.Publishdate = v.Publishdate
		contents.Createdate = v.Createdate

		getListPaggingResponse = append(getListPaggingResponse, contents)
		totalRow = *v.Totalrow
		//isNext = v.IsNext
	}

	//* Get Total Page
	totalPages := 0

	if totalRow > 0 {
		totalPagesPre := (totalRow / request.Pagging.PageSize)

		if totalRow%request.Pagging.PageSize == 0 {
			totalPages = totalPagesPre
		} else {
			totalPages = totalPagesPre + 1
		}
	}

	var result dt.ContentsListPaggingResponse
	result.ListData = getListPaggingResponse
	result.TotalRow = &totalRow
	//result.IsNext = isNext
	result.TotalPage = &totalPages

	return &result, nil
}
