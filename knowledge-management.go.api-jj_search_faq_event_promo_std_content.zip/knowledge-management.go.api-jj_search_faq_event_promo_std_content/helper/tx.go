package helper

import (
	"boilerplate-go-fiber/domain/general"
	"boilerplate-go-fiber/exception"
	"context"
	"database/sql"

	"github.com/gofiber/fiber/v2"
	"github.com/sirupsen/logrus"
)

func InitTx(ctx context.Context, conf *general.SectionService, db *sql.DB, log *logrus.Logger) general.InitTx {
	init := general.InitTx{
		Ctx:  ctx,
		Conf: conf,
		DB:   db,
		Log:  log,
	}
	return init
}

func ExecTx(init general.InitTx, fn func(tx *sql.Tx) *general.Error) *general.Error {
	tx, err := init.DB.BeginTx(init.Ctx, nil)
	if err != nil {
		return exception.NewError(fiber.StatusInternalServerError, "Failed to BeginTx", "Gagal untuk BeginTx")
	}

	errData := fn(tx)
	if errData != nil {
		err := tx.Rollback()
		init.Log.Warn("Rollback transaction")
		if err != nil {
			return exception.NewError(fiber.StatusInternalServerError, "Failed to rollback transaction", "Gagal untuk rollback transaction")
		}
		return exception.NewError(errData.Code, errData.Message, errData.MessageInd)
	}

	tx.Commit()
	return nil
}
