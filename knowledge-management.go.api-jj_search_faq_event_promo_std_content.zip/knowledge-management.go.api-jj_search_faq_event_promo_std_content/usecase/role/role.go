package role

import (
	dr "boilerplate-go-fiber/domain/role"
	"boilerplate-go-fiber/exception"
	"boilerplate-go-fiber/helper"
	"fmt"
	"math"
	"time"

	"boilerplate-go-fiber/domain/general"
	"boilerplate-go-fiber/repository"
	rr "boilerplate-go-fiber/repository/role"
	"context"
	"database/sql"

	"github.com/gofiber/fiber/v2"
	"github.com/sirupsen/logrus"
)

type RoleDataUsecase struct {
	Repo rr.RoleDataRepoItf
	Conf *general.SectionService
	DB   *sql.DB
	Log  *logrus.Logger
}

func newRoleDataUsecase(r repository.Repo, conf *general.SectionService, db *sql.DB, logger *logrus.Logger) RoleDataUsecase {
	return RoleDataUsecase{
		//Repo: r.Role.Role,
		Conf: conf,
		DB:   db,
		Log:  logger,
	}
}

type RoleDataUsecaseItf interface {
	CreateRole(ctx context.Context, dataReq *dr.CreateRoleRequest, name string) (*general.Error, *dr.CreateRoleScan)
	GetByRoleId(ctx context.Context, roleId int64) (*general.Error, *dr.GetRoleScan)
	GetByRoleName(ctx context.Context, roleName string) (*general.Error, *dr.GetRoleScan)
	ListRole(ctx context.Context, page int, pageSize int) (*general.Error, *[]dr.ListRoleScan, int, int)
	UpdateRole(ctx context.Context, dataReq *dr.UpdateRoleRequest, name string) (*general.Error, *dr.UpdateRoleScan)
	UpdateStatusRole(ctx context.Context, dataReq *dr.UpdateStatusRoleRequest, name string) (*general.Error, *dr.UpdateStatusRoleScan)
}

func (ru RoleDataUsecase) CreateRole(ctx context.Context, dataReq *dr.CreateRoleRequest, name string) (*general.Error, *dr.CreateRoleScan) {

	//* Validate data request
	dataErr := helper.ValidateDataRequest(dataReq)
	if dataErr != nil {
		return dataErr, nil
	}

	//* Validate local name
	if name == "" {
		return exception.NewError(fiber.StatusNotFound, "Name not found", "Name tidak ditemukan"), nil
	}

	//* Check duplicate role name
	err, dataRole := ru.Repo.GetRoleByRoleName(ctx, dataReq.RoleName)
	if err != nil {
		return exception.NewError(fiber.StatusInternalServerError, err.Error(), "Role tidak ditemukan"), nil
	}
	if dataRole.RoleName == dataReq.RoleName {
		return exception.NewError(fiber.StatusBadRequest, "Role name is already exist", "Role name sudah ada"), nil
	}

	//* Insert data to param
	param := new(dr.CreateRoleParam)
	param.RoleName = dataReq.RoleName
	param.IsActive = dataReq.IsActive
	param.CreatedBy = name
	param.CreatedAt = time.Now()

	//* Repo insert new role
	err, respData := ru.Repo.CreateRole(ctx, *param)
	if err != nil {
		return exception.NewError(fiber.StatusInternalServerError, err.Error(), "Gagal membuat role baru"), nil
	}

	//* Create success response
	return nil, respData
}

func (ru RoleDataUsecase) GetByRoleId(ctx context.Context, roleId int64) (*general.Error, *dr.GetRoleScan) {

	//* Validate data request
	if roleId == 0 {
		return exception.NewError(fiber.StatusBadRequest, "Role id can't be empty", "Role id tidak boleh kosong"), nil
	}

	//* Repo get role by id
	err, respData := ru.Repo.GetRoleByRoleId(ctx, roleId)
	if err != nil {
		return exception.NewError(fiber.StatusInternalServerError, err.Error(), "Role tidak ditemukan"), nil
	}

	//* Create success response
	return nil, respData
}

func (ru RoleDataUsecase) GetByRoleName(ctx context.Context, roleName string) (*general.Error, *dr.GetRoleScan) {

	//* Validate data request
	if roleName == "" {
		return exception.NewError(fiber.StatusBadRequest, "Role name can't be empty", "Role name tidak boleh kosong"), nil
	}

	//* Repo get role by name
	err, respData := ru.Repo.GetRoleByRoleName(ctx, roleName)
	if err != nil {
		return exception.NewError(fiber.StatusInternalServerError, err.Error(), "Role tidak ditemukan"), nil
	}

	//* Create success response
	return nil, respData
}

func (ru RoleDataUsecase) ListRole(ctx context.Context, page int, pageSize int) (*general.Error, *[]dr.ListRoleScan, int, int) {

	//* Validate data request
	if page == 0 {
		return exception.NewError(fiber.StatusBadRequest, "Page can't be empty", "Page tidak boleh kosong"), nil, 0, 0
	}

	//* Pagination
	switch {
	case pageSize > 100:
		pageSize = 100
	case pageSize < 0:
		pageSize = 10
	}

	respData := new([]dr.ListRoleScan)
	var total int
	var err error

	if pageSize == 0 {
		//* Repo get role by name
		err, respData, total = ru.Repo.ListRole(ctx)
		if err != nil {
			return exception.NewError(fiber.StatusInternalServerError, err.Error(), "Role tidak ditemukan"), nil, 0, 0
		}
	} else {
		//* Repo get role by name
		err, respData, total = ru.Repo.ListRoleWithLimit(ctx, page, pageSize)
		if err != nil {
			return exception.NewError(fiber.StatusInternalServerError, err.Error(), "Role tidak ditemukan"), nil, 0, 0
		}
	}

	lastPage := int(math.Ceil(float64(total) / float64(pageSize)))

	//* Create success response
	return nil, respData, total, lastPage
}

func (ru RoleDataUsecase) UpdateRole(ctx context.Context, dataReq *dr.UpdateRoleRequest, name string) (*general.Error, *dr.UpdateRoleScan) {

	//* Validate data request
	dataErr := helper.ValidateDataRequest(dataReq)
	if dataErr != nil {
		return dataErr, nil
	}

	//* Validate local name
	if name == "" {
		return exception.NewError(fiber.StatusNotFound, "Name not found", "Name tidak ditemukan"), nil
	}

	//* Check valid role id
	err, _ := ru.Repo.GetRoleByRoleId(ctx, dataReq.RoleID)
	if err != nil {
		return exception.NewError(fiber.StatusInternalServerError, err.Error(), "Role tidak ditemukan"), nil
	}

	//* Check duplicate role name
	err, dataRole := ru.Repo.GetRoleByRoleName(ctx, dataReq.RoleName)
	if err != nil {
		return exception.NewError(fiber.StatusInternalServerError, err.Error(), "Role tidak ditemukan"), nil
	}
	if dataRole.RoleID != dataReq.RoleID {
		if dataRole.RoleName == dataReq.RoleName {
			return exception.NewError(fiber.StatusBadRequest, "Role name is already exist", "Role name sudah ada"), nil
		}
	}

	timeNow := time.Now()

	//* Insert data to param
	param := new(dr.UpdateRoleParam)
	param.RoleID = dataReq.RoleID
	param.RoleName = dataReq.RoleName
	param.IsActive = dataReq.IsActive
	param.UpdatedBy = &name
	param.UpdatedAt = &timeNow

	//* Repo update role
	err, respData := ru.Repo.UpdateRole(ctx, *param)
	if err != nil {
		return exception.NewError(fiber.StatusInternalServerError, err.Error(), "Gagal update role"), nil
	}

	//* Create success response
	return nil, respData
}

func (ru RoleDataUsecase) UpdateStatusRole(ctx context.Context, dataReq *dr.UpdateStatusRoleRequest, name string) (*general.Error, *dr.UpdateStatusRoleScan) {

	//* Validate data request
	dataErr := helper.ValidateDataRequest(dataReq)
	if dataErr != nil {
		return dataErr, nil
	}

	//* Validate local name
	if name == "" {
		return exception.NewError(fiber.StatusNotFound, "Name not found", "Name tidak ditemukan"), nil
	}

	//* Check valid role id
	err, eRole := ru.Repo.GetRoleByRoleId(ctx, dataReq.RoleID)
	if err != nil {
		return exception.NewError(fiber.StatusInternalServerError, err.Error(), "Role tidak ditemukan"), nil
	}

	if dataReq.IsActive == eRole.IsActive {
		var status string
		if dataReq.IsActive {
			status = "active"
		} else {
			status = "inactive"
		}
		return exception.NewError(fiber.StatusBadRequest, fmt.Sprintf("Role with id %v is already %s", dataReq.RoleID, status), fmt.Sprintf("Role dengan id %v sudah %s", dataReq.RoleID, status)), nil
	}

	timeNow := time.Now()

	//* Insert data to param
	param := new(dr.UpdateStatusRoleParam)
	param.RoleID = dataReq.RoleID
	param.IsActive = dataReq.IsActive
	param.UpdatedBy = &name
	param.UpdatedAt = &timeNow

	//* Repo update role
	err, respData := ru.Repo.UpdateStatusRole(ctx, *param)
	if err != nil {
		return exception.NewError(fiber.StatusInternalServerError, err.Error(), "Gagal mengaktifkan atau menonaktifkan role"), nil
	}

	//* Create success response
	return nil, respData
}
