package users

import (
	"boilerplate-go-fiber/domain/general"
	"boilerplate-go-fiber/usecase"

	"github.com/sirupsen/logrus"
)

type UsersHandler struct {
	Users UsersDataHandler
}

func NewCoreHandler(uc usecase.Usecase, conf *general.SectionService, logger *logrus.Logger) UsersHandler {
	return UsersHandler{
		Users: newUsersHandler(uc, conf, logger),
	}
}
