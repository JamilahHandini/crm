package role

import (
	"database/sql"

	"github.com/sirupsen/logrus"
)

type RoleRepo struct {
	Role RoleDataRepoItf
}

func NewMasterRepo(db *sql.DB, log *logrus.Logger) RoleRepo {
	return RoleRepo{
		Role: newRoleDataRepo(db),
	}
}
