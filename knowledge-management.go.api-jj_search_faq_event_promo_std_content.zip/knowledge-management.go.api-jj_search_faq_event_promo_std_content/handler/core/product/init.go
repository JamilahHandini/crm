package product

import (
	"boilerplate-go-fiber/domain/general"
	"boilerplate-go-fiber/usecase"

	"github.com/sirupsen/logrus"
)

type ProductHandler struct {
	Product ProductDataHandler
}

func NewCoreHandler(uc usecase.Usecase, conf *general.SectionService, logger *logrus.Logger) ProductHandler {
	return ProductHandler{
		Product: newProductHandler(uc, conf, logger),
	}
}
