package handler

import (
	"boilerplate-go-fiber/domain/general"
	ch "boilerplate-go-fiber/handler/core"
	gh "boilerplate-go-fiber/handler/general"

	"boilerplate-go-fiber/usecase"

	"github.com/sirupsen/logrus"
)

type Handler struct {
	Core    ch.CoreHandler
	General gh.GeneralHandler
}

func NewHandler(uc usecase.Usecase, conf *general.SectionService, log *logrus.Logger) Handler {
	return Handler{
		Core:    ch.NewCoreHandler(uc, conf, log),
		General: gh.NewHandler(uc, conf, log),
	}
}
