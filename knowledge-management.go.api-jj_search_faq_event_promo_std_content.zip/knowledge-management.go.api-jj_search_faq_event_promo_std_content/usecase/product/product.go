package product

import (
	"boilerplate-go-fiber/domain/general"
	"boilerplate-go-fiber/exception"
	"boilerplate-go-fiber/infra"
	"boilerplate-go-fiber/repository"

	dt "boilerplate-go-fiber/domain/product"

	ru "boilerplate-go-fiber/repository/product"

	"github.com/gofiber/fiber"
	"github.com/sirupsen/logrus"
)

type ProductDataUsecaseItf interface {
	GetAllProduct() ([]dt.ListProduct, *general.Error)
}

type ProductDataUsecase struct {
	Repo   ru.ProductDataRepoItf
	DBList *infra.DatabaseList
	Conf   *general.SectionService
	Log    *logrus.Logger
}

func newProductDataUsecase(r repository.Repo, conf *general.SectionService, logger *logrus.Logger, dbList *infra.DatabaseList) ProductDataUsecase {
	return ProductDataUsecase{
		Repo:   r.Product.Product,
		Conf:   conf,
		Log:    logger,
		DBList: dbList,
	}
}

func (ut ProductDataUsecase) GetAllProduct() ([]dt.ListProduct, *general.Error) {

	result, err := ut.Repo.GetAllProduct()
	if err != nil {
		ut.Log.Info(err)
		return nil, exception.NewError(fiber.StatusBadRequest, "error get data to DB", "error meminta data ke DB")
	}

	return result, nil
}
