package contents

import (
	"boilerplate-go-fiber/domain/general"
	"boilerplate-go-fiber/usecase"

	"github.com/sirupsen/logrus"
)

type ContentsHandler struct {
	Contents ContentsDataHandler
}

func NewCoreHandler(uc usecase.Usecase, conf *general.SectionService, logger *logrus.Logger) ContentsHandler {
	return ContentsHandler{
		Contents: newContentsHandler(uc, conf, logger),
	}
}
