package role

import (
	dr "boilerplate-go-fiber/domain/role"
	"context"
	"database/sql"
	"errors"
	"log"
)

type RoleDataRepo struct {
	DB *sql.DB
}

func newRoleDataRepo(db *sql.DB) RoleDataRepo {
	return RoleDataRepo{
		DB: db,
	}
}

type RoleDataRepoItf interface {
	CreateRole(ctx context.Context, arg dr.CreateRoleParam) (error, *dr.CreateRoleScan)
	GetRoleByRoleId(ctx context.Context, roleId int64) (error, *dr.GetRoleScan)
	GetRoleByRoleName(ctx context.Context, roleName string) (error, *dr.GetRoleScan)
	ListRole(ctx context.Context) (error, *[]dr.ListRoleScan, int)
	ListRoleWithLimit(ctx context.Context, page int, pageSize int) (error, *[]dr.ListRoleScan, int)
	UpdateRole(ctx context.Context, arg dr.UpdateRoleParam) (error, *dr.UpdateRoleScan)
	UpdateStatusRole(ctx context.Context, arg dr.UpdateStatusRoleParam) (error, *dr.UpdateStatusRoleScan)
}

const (
	qInsertRole = `
	INSERT INTO role(role_name, created_by, created_at, is_active)
	VALUES ($1, $2, $3, $4)
	RETURNING role_id, role_name, created_by, created_at, is_active;
	`
	qGetRoleByRoleId = `
	SELECT role_id, role_name, created_by, created_at, updated_by, updated_at, is_active
	FROM role
	WHERE role_id = $1;
	`
	qGetRoleByRoleName = `
	SELECT role_id, role_name, created_by, created_at, updated_by, updated_at, is_active
	FROM role
	WHERE role_name = $1;
	`
	qGetTotalRowRole = `
	SELECT COUNT(role_id) AS total FROM role;
	`
	qListRole = `
	SELECT role_id, role_name, created_by, created_at, updated_by, updated_at, is_active
	FROM role
	`
	qListRoleWithLimit = `
	SELECT role_id, role_name, created_by, created_at, updated_by, updated_at, is_active
	FROM role
	LIMIT $1 OFFSET $2;
	`
	qUpdateRole = `
	UPDATE role
	SET role_name = $1,
		updated_by = $2,
		updated_at = $3,
		is_active = $4
	WHERE role_id = $5
	RETURNING role_id, role_name, updated_by, updated_at, is_active;
	`
	qUpdateStatusRole = `
	UPDATE role
	SET is_active = $1,
		updated_by = $2,
		updated_at = $3
	WHERE role_id = $4
	RETURNING role_id, role_name, updated_by, updated_at, is_active;
	`
)

func (rr RoleDataRepo) CreateRole(ctx context.Context, arg dr.CreateRoleParam) (error, *dr.CreateRoleScan) {
	row := rr.DB.QueryRowContext(ctx, qInsertRole,
		arg.RoleName,
		arg.CreatedBy,
		arg.CreatedAt,
		arg.IsActive,
	)
	var response dr.CreateRoleScan
	err := row.Scan(
		&response.RoleID,
		&response.RoleName,
		&response.CreatedBy,
		&response.CreatedAt,
		&response.IsActive,
	)
	if err != nil && err != sql.ErrNoRows {
		return err, nil
	}
	return nil, &response
}

func (rr RoleDataRepo) GetRoleByRoleId(ctx context.Context, roleId int64) (error, *dr.GetRoleScan) {
	row := rr.DB.QueryRowContext(ctx, qGetRoleByRoleId, roleId)
	var response dr.GetRoleScan
	err := row.Scan(
		&response.RoleID,
		&response.RoleName,
		&response.CreatedBy,
		&response.CreatedAt,
		&response.UpdatedBy,
		&response.UpdatedAt,
		&response.IsActive,
	)
	if err != nil && err != sql.ErrNoRows {
		return err, nil
	}
	return nil, &response
}

func (rr RoleDataRepo) GetRoleByRoleName(ctx context.Context, roleName string) (error, *dr.GetRoleScan) {
	row := rr.DB.QueryRowContext(ctx, qGetRoleByRoleName, roleName)
	var response dr.GetRoleScan
	err := row.Scan(
		&response.RoleID,
		&response.RoleName,
		&response.CreatedBy,
		&response.CreatedAt,
		&response.UpdatedBy,
		&response.UpdatedAt,
		&response.IsActive,
	)
	if err != nil && err != sql.ErrNoRows {
		return err, nil
	}
	return nil, &response
}

func (rr RoleDataRepo) ListRole(ctx context.Context) (error, *[]dr.ListRoleScan, int) {
	rows, err := rr.DB.QueryContext(ctx, qListRole)
	if err != nil {
		return err, nil, 0
	}
	defer rows.Close()
	var responses []dr.ListRoleScan
	for rows.Next() {
		var response dr.ListRoleScan
		if err := rows.Scan(
			&response.RoleID,
			&response.RoleName,
			&response.CreatedBy,
			&response.CreatedAt,
			&response.UpdatedBy,
			&response.UpdatedAt,
			&response.IsActive,
		); err != nil {
			return err, nil, 0
		}
		responses = append(responses, response)
	}
	if err := rows.Close(); err != nil {
		return err, nil, 0
	}
	if err := rows.Err(); err != nil {
		return err, nil, 0
	}
	total := len(responses)
	log.Println(total)
	if total == 0 {
		return errors.New("Roles not found"), nil, 0
	}
	return nil, &responses, total
}

func (rr RoleDataRepo) ListRoleWithLimit(ctx context.Context, page int, pageSize int) (error, *[]dr.ListRoleScan, int) {
	row := rr.DB.QueryRowContext(ctx, qGetTotalRowRole)
	var total int
	err := row.Scan(&total)
	if err != nil && err != sql.ErrNoRows {
		return err, nil, 0
	}
	rows, err := rr.DB.QueryContext(ctx, qListRoleWithLimit, pageSize, (page-1)*pageSize)
	if err != nil {
		return err, nil, 0
	}
	defer rows.Close()
	var responses []dr.ListRoleScan
	for rows.Next() {
		var response dr.ListRoleScan
		if err := rows.Scan(
			&response.RoleID,
			&response.RoleName,
			&response.CreatedBy,
			&response.CreatedAt,
			&response.UpdatedBy,
			&response.UpdatedAt,
			&response.IsActive,
		); err != nil {
			return err, nil, 0
		}
		responses = append(responses, response)
	}
	if err := rows.Close(); err != nil {
		return err, nil, 0
	}
	if err := rows.Err(); err != nil {
		return err, nil, 0
	}
	return nil, &responses, total
}

func (rr RoleDataRepo) UpdateRole(ctx context.Context, arg dr.UpdateRoleParam) (error, *dr.UpdateRoleScan) {
	row := rr.DB.QueryRowContext(ctx, qUpdateRole,
		arg.RoleName,
		arg.UpdatedBy,
		arg.UpdatedAt,
		arg.IsActive,
		arg.RoleID,
	)
	var response dr.UpdateRoleScan
	err := row.Scan(
		&response.RoleID,
		&response.RoleName,
		&response.UpdatedBy,
		&response.UpdatedAt,
		&response.IsActive,
	)
	if err != nil {
		return err, nil
	}
	return nil, &response
}

func (rr RoleDataRepo) UpdateStatusRole(ctx context.Context, arg dr.UpdateStatusRoleParam) (error, *dr.UpdateStatusRoleScan) {
	row := rr.DB.QueryRowContext(ctx, qUpdateStatusRole,
		arg.IsActive,
		arg.UpdatedBy,
		arg.UpdatedAt,
		arg.RoleID,
	)
	var response dr.UpdateStatusRoleScan
	err := row.Scan(
		&response.RoleID,
		&response.RoleName,
		&response.UpdatedBy,
		&response.UpdatedAt,
		&response.IsActive,
	)
	if err != nil {
		return err, nil
	}
	return nil, &response
}
