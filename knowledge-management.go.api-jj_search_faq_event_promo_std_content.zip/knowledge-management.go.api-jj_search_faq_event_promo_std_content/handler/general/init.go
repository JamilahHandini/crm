package general

import (
	"boilerplate-go-fiber/domain/general"
	"boilerplate-go-fiber/usecase"

	"github.com/sirupsen/logrus"
)

type GeneralHandler struct {
	General GeneralDataHandler
}

func NewHandler(uc usecase.Usecase, conf *general.SectionService, log *logrus.Logger) GeneralHandler {
	return GeneralHandler{
		General: newGeneralHandler(uc, conf, log),
	}
}

type GeneralDataHandler struct {
	conf *general.SectionService
	log  *logrus.Logger
}

func newGeneralHandler(uc usecase.Usecase, conf *general.SectionService, log *logrus.Logger) GeneralDataHandler {
	return GeneralDataHandler{
		conf: conf,
		log:  log,
	}
}
