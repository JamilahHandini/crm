package routes

import (
	"boilerplate-go-fiber/handler"

	"github.com/gofiber/fiber/v2"
)

func RouteRole(api fiber.Router, handler handler.Handler) {
	api.Post("/add", handler.Core.Role.Role.CreateRole)
	api.Get("/findbyid", handler.Core.Role.Role.FindByRoleId)
	api.Get("/findbyname", handler.Core.Role.Role.FindByRoleName)
	api.Get("/list", handler.Core.Role.Role.ListRole)
	api.Put("/update", handler.Core.Role.Role.UpdateRole)
	api.Put("/updatestatus", handler.Core.Role.Role.UpdateStatusRole)
}
