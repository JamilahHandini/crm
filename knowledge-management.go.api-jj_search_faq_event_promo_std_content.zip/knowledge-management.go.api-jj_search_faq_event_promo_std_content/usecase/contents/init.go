package contents

import (
	"boilerplate-go-fiber/domain/general"
	"boilerplate-go-fiber/infra"
	"boilerplate-go-fiber/repository"

	"github.com/sirupsen/logrus"
)

type ContentsUsecase struct {
	Contents ContentsDataUsecaseItf
}

func NewUsecase(repo repository.Repo, conf *general.SectionService, dbList *infra.DatabaseList, logger *logrus.Logger) ContentsUsecase {
	return ContentsUsecase{
		Contents: newContentsDataUsecase(repo, conf, logger, dbList),
	}
}
