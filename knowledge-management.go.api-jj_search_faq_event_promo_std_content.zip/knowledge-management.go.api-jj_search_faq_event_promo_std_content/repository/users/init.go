package users

import (
	"boilerplate-go-fiber/infra"

	"github.com/sirupsen/logrus"
)

type UsersRepo struct {
	Users UsersDataRepoItf
}

func NewMasterRepo(db *infra.DatabaseList, logger *logrus.Logger) UsersRepo {
	return UsersRepo{
		Users: newUsersDataRepo(db, logger),
	}
}
