package contents

import (
	dg "boilerplate-go-fiber/domain/general"
)

type FAQsData struct {
	Rowno       *int    `json:"rowno" db:"rowno"`
	Id          *int    `json:"id" db:"id"`
	Title       *string `json:"title" db:"title"`
	Description *string `json:"description" db:"description"`
	Createdate  *string `json:"createdate " db:"createdate"`
	Publishdate *string `json:"publishdate" db:"publishdate"`
	Totalrow    *int    `json:"totalrow" db:"totalrow"`
}

// type GetFAQPaging struct {
// 	Totalrow *int `json:"t" db:"rowno"`
// 	Page     *int `json:"t" db:"rowno"`
// 	PageSize *int `json:"t" db:"rowno"`
// 	//Data []FAQsData
// }

type ContentsListPaggingResponse struct {
	ListData  []FAQsData `json:"listdata"`
	TotalRow  *int           `json:"totalrow"`
	TotalPage *int           `json:"totalpage"`
	//IsNext    bool           `json:"isnext"`
}

type ContentListPaggingRequest struct {
	//IsActive *bool               `json:"isactive"`
	Pagging dg.SeacrhDataPaging `json:"pagging"`
}
