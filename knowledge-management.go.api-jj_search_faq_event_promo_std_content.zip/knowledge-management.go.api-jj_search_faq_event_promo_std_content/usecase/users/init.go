package users

import (
	"boilerplate-go-fiber/domain/general"
	"boilerplate-go-fiber/infra"
	"boilerplate-go-fiber/repository"

	"github.com/sirupsen/logrus"
)

type UsersUsecase struct {
	Users UsersDataUsecaseItf
}

func NewUsecase(repo repository.Repo, conf *general.SectionService, dbList *infra.DatabaseList, logger *logrus.Logger) UsersUsecase {
	return UsersUsecase{
		Users: newUsersDataUsecase(repo, conf, logger, dbList),
	}
}
