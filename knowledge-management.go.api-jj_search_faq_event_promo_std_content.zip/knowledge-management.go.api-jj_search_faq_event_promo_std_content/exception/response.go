package exception

import (
	"boilerplate-go-fiber/domain/general"
	dg "boilerplate-go-fiber/domain/general"
	"boilerplate-go-fiber/utils"
	"fmt"

	"github.com/gofiber/fiber/v2"
	"github.com/sirupsen/logrus"
)

func InitException(c *fiber.Ctx, conf *general.SectionService, log *logrus.Logger) dg.InitialExceptionCreateResponse {
	init := dg.InitialExceptionCreateResponse{
		Ctx: c,
		Log: log,
	}
	return init
}

func CreateResponse(exc dg.InitialExceptionCreateResponse, code int, message string, messageInd string, data interface{}) error {
	RespData := dg.ResponseData{
		Data: data,
		Status: dg.StatusResponseData{
			Code:       code,
			Message:    message,
			MessageInd: messageInd,
		},
		TimeStamp: utils.GenerateTimeNowJakarta(),
	}

	switch code {
	case fiber.StatusOK:
		RespData.Status.Type = "OK"
	case fiber.StatusBadRequest:
		RespData.Status.Type = "BAD REQUEST"
	case fiber.StatusUnauthorized:
		RespData.Status.Type = "UNAUTHORIZED"
	case fiber.StatusNotFound:
		RespData.Status.Type = "NOT FOUND"
	case fiber.StatusInternalServerError:
		RespData.Status.Type = "INTERNAL SERVER ERROR"
	}

	return exc.Ctx.Status(code).JSON(RespData)
}

func CreateResponse_Log(exc dg.InitialExceptionCreateResponse, code int, message string, messageInd string, data interface{}) error {

	requestId, _ := utils.GetUUID()

	RespData := dg.ResponseData{
		RequestId: requestId,
		Data:      data,
		Status: dg.StatusResponseData{
			Code:       code,
			Message:    message,
			MessageInd: messageInd,
		},
		TimeStamp: utils.GenerateTimeNowJakarta(),
	}

	if code == fiber.StatusOK {
		RespData.Status.Type = "OK"
		exc.Log.Info(fmt.Sprintf(`code="%v" method="%s" path="%v" msg="%s" msgInd="%s"`,
			RespData.Status.Code,
			exc.Ctx.Method(),
			exc.Ctx.Path(),
			RespData.Status.Message,
			RespData.Status.MessageInd,
		))
	} else {
		switch code {
		case fiber.StatusOK:
			RespData.Status.Type = "OK"
		case fiber.StatusBadRequest:
			RespData.Status.Type = "BAD REQUEST"
		case fiber.StatusUnauthorized:
			RespData.Status.Type = "UNAUTHORIZED"
		case fiber.StatusNotFound:
			RespData.Status.Type = "NOT FOUND"
		case fiber.StatusInternalServerError:
			RespData.Status.Type = "INTERNAL SERVER ERROR"
		}
		exc.Log.Error(fmt.Sprintf(`requestId="%v" code="%v" method="%s" path="%v" msg="%s" msgInd="%s"`,
			requestId,
			RespData.Status.Code,
			exc.Ctx.Method(),
			exc.Ctx.Path(),
			RespData.Status.Message,
			RespData.Status.MessageInd,
		))
	}

	return exc.Ctx.Status(code).JSON(RespData)
}

func CreateResponse_Page(exc dg.InitialExceptionCreateResponse, code int, message string, messageInd string, data interface{}, page int, lastPage int, totalData int) error {

	requestId, _ := utils.GetUUID()

	RespData := dg.ResponseData{
		RequestId: requestId,
		Data:      data,
		Status: dg.StatusResponseData{
			Code:       code,
			Message:    message,
			MessageInd: messageInd,
		},
		TimeStamp: utils.GenerateTimeNowJakarta(),
		Pagination: dg.Pagination{
			Page:      page,
			LastPage:  lastPage,
			TotalData: totalData,
		},
	}

	switch code {
	case fiber.StatusOK:
		RespData.Status.Type = "OK"
	case fiber.StatusBadRequest:
		RespData.Status.Type = "BAD REQUEST"
	case fiber.StatusUnauthorized:
		RespData.Status.Type = "UNAUTHORIZED"
	case fiber.StatusNotFound:
		RespData.Status.Type = "NOT FOUND"
	case fiber.StatusInternalServerError:
		RespData.Status.Type = "INTERNAL SERVER ERROR"
	}

	return exc.Ctx.Status(code).JSON(RespData)
}

func CreateResponse_Log_Page(exc dg.InitialExceptionCreateResponse, code int, message string, messageInd string, data interface{}, page int, lastPage int, totalData int) error {
	RespData := dg.ResponseData{
		Data: data,
		Status: dg.StatusResponseData{
			Code:       code,
			Message:    message,
			MessageInd: messageInd,
		},
		TimeStamp: utils.GenerateTimeNowJakarta(),
		Pagination: dg.Pagination{
			Page:      page,
			LastPage:  lastPage,
			TotalData: totalData,
		},
	}

	if code == fiber.StatusOK {
		RespData.Status.Type = "OK"
		exc.Log.Info(fmt.Sprintf(`code="%v" method="%s" path="%v" msg="%s" msgInd="%s"`,
			RespData.Status.Code,
			exc.Ctx.Method(),
			exc.Ctx.Path(),
			RespData.Status.Message,
			RespData.Status.MessageInd,
		))
	} else {
		switch code {
		case fiber.StatusOK:
			RespData.Status.Type = "OK"
		case fiber.StatusBadRequest:
			RespData.Status.Type = "BAD REQUEST"
		case fiber.StatusUnauthorized:
			RespData.Status.Type = "UNAUTHORIZED"
		case fiber.StatusNotFound:
			RespData.Status.Type = "NOT FOUND"
		case fiber.StatusInternalServerError:
			RespData.Status.Type = "INTERNAL SERVER ERROR"
		}
		exc.Log.Error(fmt.Sprintf(`code="%v" method="%s" path="%v" msg="%s" msgInd="%s"`,
			RespData.Status.Code,
			exc.Ctx.Method(),
			exc.Ctx.Path(),
			RespData.Status.Message,
			RespData.Status.MessageInd,
		))
	}

	return exc.Ctx.Status(code).JSON(RespData)
}
