package general

type SeacrhDataPaging struct {
	PageNumber int     `json:"pagenumber"`
	PageSize   int     `json:"pagesize"`
	OrderBy    *string `json:"orderby"`
	OrderType  *string `json:"ordertype"`
	SearchKey  *string `json:"searchkey"`
}
